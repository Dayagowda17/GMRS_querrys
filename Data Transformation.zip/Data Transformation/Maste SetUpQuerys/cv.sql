
USE GMRSJUNE2025
select *
--delete
FROM t_allmastertype WHERE Name = 'CV'
select *
--delete 
from t_allmaster where mastertype=523
DECLARE @NextPKID INT;
DECLARE @master_type INT=-1;
DECLARE @Company_ID INT = 98;
DECLARE @CreatedBy INT = 90;
DECLARE @CreatedDate DateTime = getdate();
DECLARE @ApprovedDate DateTime = getdate();
DECLARE @ApprovedBy INT = 90;


DECLARE @RejectionRemark CHAR = NULL;
DECLARE @isResubmit CHAR = NULL;
SELECT @master_type=PKID FROM t_allmastertype WHERE Name = 'CV';
SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
--print  @CreatedDate
--SELECT * FROM t_allmaster
--WHERE MasterType = @master_type
  --AND CompanyID = @Company_ID
  --AND CreateBy = @CreatedBy
  ---AND ApprovedBy = @ApprovedBy,@RejectionRemark,@isResubmit;


 
  insert into t_AllMaster values( @NextPKID,'0.000000','0.000000','0.000000', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

   
  insert into t_AllMaster values( @NextPKID,'0.035069','0.035069','0.035069', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


  go