
USE GMRSJUNE2025
select *
--delete
FROM t_allmastertype WHERE Name = 'City gate'
select *
--delete 
from t_allmaster where mastertype=522
DECLARE @NextPKID INT;
DECLARE @master_type INT=-1;
DECLARE @Company_ID INT = 98;
DECLARE @CreatedBy INT = 90;
DECLARE @CreatedDate DateTime = getdate();
DECLARE @ApprovedDate DateTime = getdate();
DECLARE @ApprovedBy INT=90;
 
DECLARE @RejectionRemark CHAR = NULL;
DECLARE @isResubmit CHAR = NULL;
SELECT @master_type=PKID FROM t_allmastertype WHERE Name = 'City gate';
SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
--print  @CreatedDate
--SELECT * FROM t_allmaster
--WHERE MasterType = @master_type
  --AND CompanyID = @Company_ID
  --AND CreateBy = @CreatedBy
  ---AND ApprovedBy = @ApprovedBy,@RejectionRemark,@isResubmit;
 
  insert into t_AllMaster values( @NextPKID,'GLEN','GLEN','GLEN-GLENMARIE', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

   
  insert into t_AllMaster values( @NextPKID,'KERT','KERT','KERT-KERTEH', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


   
  insert into t_AllMaster values( @NextPKID,'KLIA','KLIA','KLIA', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


   
  insert into t_AllMaster values( @NextPKID,'PG','PG','PG-PASIR GUDANG', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

   
  insert into t_AllMaster values( @NextPKID,'SER','SER','SER-SERDANG', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

   
  insert into t_AllMaster values( @NextPKID,'na','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

  go