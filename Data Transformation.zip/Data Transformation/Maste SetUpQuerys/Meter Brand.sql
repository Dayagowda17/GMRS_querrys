
select *
--delete
FROM t_allmastertype WHERE Name = 'Meter Brand'
select *
--delete 
from t_allmaster where mastertype=68
DECLARE @NextPKID INT;
DECLARE @master_type INT=-1;
DECLARE @Company_ID INT = 98;
DECLARE @CreatedBy INT = 90;
DECLARE @CreatedDate DateTime = getdate();
DECLARE @ApprovedDate DateTime = getdate();
DECLARE @ApprovedBy INT = 90;
SELECT @master_type=PKID FROM t_allmastertype WHERE Name = 'Meter Brand';
SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
--print  @CreatedDate
--SELECT * FROM t_allmaster
--WHERE MasterType = @master_type
  --AND CompanyID = @Company_ID
  --AND CreateBy = @CreatedBy
  ---AND ApprovedBy = @ApprovedBy,null,null;
 
  insert into t_AllMaster values( @NextPKID,'1','ACTARIS','ACTARIS', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

  insert into t_AllMaster values( @NextPKID,'2','AICHI TOKEI','AICHI TOKEI', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

  insert into t_AllMaster values( @NextPKID,'3','ALPHA','ALPHA', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


  insert into t_AllMaster values( @NextPKID,'4','ARIETA 2000','ARIETA 2000', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


  insert into t_AllMaster values( @NextPKID,'5','BETA','BETA', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'6','CGS','CGS', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'7','CUBIC','CUBIC', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'8','DAEHAN GM CORPORATION','DAEHAN GM CORPORATION', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'9','DAEHAN SR3','DAEHAN SR3', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'10','DAEMYOUNG I&T','DAEMYOUNG I&T', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'11','DAESUNG','DAESUNG', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'12','DITGM','DITGM', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'13','DMIT','DMIT', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'14','DRESSER','DRESSER', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'15','ELSTER','ELSTER', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)




  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'16','FMG','FMG', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'17','GALLUS','GALLUS', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'18','GALLUS 2000','GALLUS 2000', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;





insert into t_AllMaster values( @NextPKID,'19','Gas Standard 4 Dial Meter','Gas Standard 4 Dial Meter', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

insert into t_AllMaster values( @NextPKID,'20','Gas Standard 5 Dial Meter','Gas Standard 5 Dial Meter', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'21','GAS STANDARD 7 DIAL METER','GAS STANDARD 7 DIAL METER', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'22','HANGZHOU BETA','HANGZHOU BETA', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

insert into t_AllMaster values( @NextPKID,'23','HK-J','HK-J', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

insert into t_AllMaster values( @NextPKID,'24','HK-J1.6H','HK-J1.6H', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'25','HK-J2.5H','HK-J2.5H', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;




insert into t_AllMaster values( @NextPKID,'26','ITRON','ITRON', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'27','KANSAI','KANSAI', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'28','KANSAI-6','KANSAI-6', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'29','KDG KAS','KDG KAS', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'30','KEUK DONG','KEUK DONG', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'31','KG-2','KG-2', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'32','PREPAID METER','PREPAID METER', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

insert into t_AllMaster values( @NextPKID,'33','QWKROM','QWKROM', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'34','RICOH','RICOH', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'35','RICOH-GR-25MM','RICOH-GR-25MM', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'36','RICOH-GR-25MM (G1.4)','RICOH-GR-25MM (G1.4)', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'37','RICOH-MPD-23A','RICOH-MPD-23A', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'38','SHAPADU INSTRUMENTS','SHAPADU INSTRUMENTS', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'39','SINTTA','SINTTA', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'40','SR-3','SR-3', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'41','WUXI ZHONGYI SMART','WUXI ZHONGYI SMART', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

insert into t_AllMaster values( @NextPKID,'42','ZDEXP','ZDEXP', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
insert into t_AllMaster values( @NextPKID,'43','ZENNER','ZENNER', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
go