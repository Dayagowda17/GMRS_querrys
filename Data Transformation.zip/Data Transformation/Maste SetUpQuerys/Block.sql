select *
--delete
FROM t_allmastertype WHERE Name = 'Block'
select *
--delete 
from t_allmaster where mastertype=63


DECLARE @NextPKID INT;
DECLARE @master_type INT=-1;
DECLARE @Company_ID INT = 98;
DECLARE @CreatedBy INT = 90;
DECLARE @CreatedDate DateTime = getdate();
DECLARE @ApprovedDate DateTime = getdate();
DECLARE @ApprovedBy,null,null INT = 90;
SELECT @master_type=PKID FROM t_allmastertype WHERE Name = 'Block';
SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
--print  @CreatedDate
--SELECT * FROM t_allmaster
--WHERE MasterType = @master_type
  --AND CompanyID = @Company_ID
  --AND CreateBy = @CreatedBy
  ---AND ApprovedBy = @ApprovedBy,null,null;
 
  insert into t_AllMaster values( @NextPKID,'00','00','00', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

  insert into t_AllMaster values( @NextPKID,'05','05','05', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

  insert into t_AllMaster values( @NextPKID,'10','10','10', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

  insert into t_AllMaster values( @NextPKID,'12','12','12', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

  insert into t_AllMaster values( @NextPKID,'15','15','15', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  
  insert into t_AllMaster values( @NextPKID,'20','20','20', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;  


insert into t_AllMaster values( @NextPKID,'25','25','25', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'30','30','30', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'35','35','35', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'40','40','40', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'45','45','45', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'46','46','46', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

  insert into t_AllMaster values( @NextPKID,'47','47','47', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'48','48','48', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'49','49','49', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'52','52','52', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'56','56','56', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'65','65','65', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'66','66','66', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'67','67','67', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'70','70','70', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'73','73','73', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'79','79','79', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'80','80','80', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'90','90','90', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'95','95','95', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'99','99','99', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,null,null)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
 go

