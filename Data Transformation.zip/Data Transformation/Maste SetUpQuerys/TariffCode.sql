
USE GMRSJUNE2025
select *
--delete
FROM t_allmastertype WHERE Name = 'Tariff Code';
select *
--delete 
from t_allmaster where mastertype=77


DECLARE @RejectionRemark CHAR = NULL;
DECLARE @isResubmit CHAR = NULL;
DECLARE @NextPKID INT;
DECLARE @master_type INT=-1;
DECLARE @Company_ID INT = 98;
DECLARE @CreatedBy INT = 90;
DECLARE @CreatedDate DateTime = getdate();
DECLARE @ApprovedDate DateTime = getdate();
DECLARE @ApprovedBy INT = 90;
SELECT @master_type=PKID FROM t_allmastertype WHERE Name = 'Tariff Code';
SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
--print  @CreatedDate
--SELECT * FROM t_allmaster
--WHERE MasterType = @master_type
  --AND CompanyID = @Company_ID
  --AND CreateBy = @CreatedBy
  ---AND ApprovedBy = @ApprovedBy,@RejectionRemark,@isResubmit;
  insert into t_AllMaster values( @NextPKID,'01','BULK RESIDENTIAL (HIGH END)','BULK RESIDENTIAL (HIGH END)', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'02','MANIFOLD (HIGH END)','MANIFOLD (HIGH END)', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
  insert into t_AllMaster values( @NextPKID,'03','BULK (MEDIUM END)','BULK (MEDIUM END)', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)  
  SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
    insert into t_AllMaster values( @NextPKID,'04','MANIFOLD (MEDIUM END)','MANIFOLD (MEDIUM END)', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
   insert into t_AllMaster values( @NextPKID,'05','BULK - WITH METER RENTAL (HIGH END)','BULK - WITH METER RENTAL (HIGH END)', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

   insert into t_AllMaster values( @NextPKID,'06','MANIFOLD WITH METER RENTAL (HIGH END)','MANIFOLD WITH METER RENTAL (HIGH END)', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


   insert into t_AllMaster values( @NextPKID,'07','BULK - NO METER RENTAL (HIGH END)','BULK - NO METER RENTAL (HIGH END)', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
   insert into t_AllMaster values( @NextPKID,'08','MANIFOLD - NO METER RENTAL (HIGH END)','MANIFOLD - NO METER RENTAL (HIGH END)', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
   insert into t_AllMaster values( @NextPKID,'09','MANIFOLD (NO METER RENTAL) - HIGH END','MANIFOLD (NO METER RENTAL) - HIGH END', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
   insert into t_AllMaster values( @NextPKID,'10','MANIFOLD (HIGH END)','MANIFOLD (HIGH END)', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
   insert into t_AllMaster values( @NextPKID,'11','BULK RESIDENTIAL - LOW END','BULK RESIDENTIAL - LOW END', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

   insert into t_AllMaster values( @NextPKID,'12','MANIFOLD - LOW END','MANIFOLD - LOW END', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
   insert into t_AllMaster values( @NextPKID,'14','MANIFOLD - HIGH END','MANIFOLD - HIGH END', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;
   insert into t_AllMaster values( @NextPKID,'15','SERINGIN RESIDENCES','SERINGIN RESIDENCES', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

   insert into t_AllMaster values( @NextPKID,'16','WESTSIDE 3','WESTSIDE 3', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

   insert into t_AllMaster values( @NextPKID,'17','RESIDENCY KIA PENG','RESIDENCY KIA PENG', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

   insert into t_AllMaster values( @NextPKID,'18','ARAVILLE','ARAVILLE', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)
 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


   insert into t_AllMaster values( @NextPKID,'40','COMMERCIAL MYDIN PRESSURE 5PSI','COMMERCIAL MYDIN PRESSURE 5PSI', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)


 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

   insert into t_AllMaster values( @NextPKID,'41','COMMERCIAL PRESSURE ( 5 PSI NEW)','COMMERCIAL PRESSURE ( 5 PSI NEW)', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

   insert into t_AllMaster values( @NextPKID,'45','COMMERCIAL (0.5 PSI)','COMMERCIAL (0.5 PSI)', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)


 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

   insert into t_AllMaster values( @NextPKID,'50','AEON MALL','AEON MALL', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


   insert into t_AllMaster values( @NextPKID,'51','LOT 10 - 5PSI','LOT 10 - 5PSI', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

   insert into t_AllMaster values( @NextPKID,'52','THE MALL','THE MALL', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

   insert into t_AllMaster values( @NextPKID,'53','5 PSI','5 PSI', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

   insert into t_AllMaster values( @NextPKID,'54','PLAZA PANTAI','PLAZA PANTAI', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)


 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


   insert into t_AllMaster values( @NextPKID,'55','PLAZA PANTAI','MPLAZA PANTAI', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)


 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;




   insert into t_AllMaster values( @NextPKID,'56','LOT 10 - 10 PSI','LOT 10 - 10 PSI', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;







   insert into t_AllMaster values( @NextPKID,'57','0.5 PSI','0.5 PSI', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;







   insert into t_AllMaster values( @NextPKID,'58','DIGITAL MALL','DIGITAL MALL', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;




   insert into t_AllMaster values( @NextPKID,'59','QUEENSBAY','QUEENSBAY', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;



   insert into t_AllMaster values( @NextPKID,'60','STC - 10 PSI','STC - 10 PSI', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;








insert into t_AllMaster values( @NextPKID,'61','WANGSA WALK 5 - PSI','WANGSA WALK 5 - PSI', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;




insert into t_AllMaster values( @NextPKID,'62','AEON MALL','AEON MALL', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;



insert into t_AllMaster values( @NextPKID,'63','CYLINDER BILLING','CYLINDER BILLING', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;



insert into t_AllMaster values( @NextPKID,'64','IPC','IPC', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;



insert into t_AllMaster values( @NextPKID,'65','WANGSA WALK - 5 PSI','WANGSA WALK - 5 PSI', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;






























insert into t_AllMaster values( @NextPKID,'66','MITSUI PREMIUM OUTLET','MITSUI PREMIUM OUTLET', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;







insert into t_AllMaster values( @NextPKID,'67','ECO SANTUARY','ECO SANTUARY', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;





insert into t_AllMaster values( @NextPKID,'68','SPICE CANOPY','SPICE CANOPY', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;





insert into t_AllMaster values( @NextPKID,'69','BELETIME DANGA BAY','BELETIME DANGA BAY', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;



insert into t_AllMaster values( @NextPKID,'70','RETAIL LICENCE - COMMERCIAL','RETAIL LICENCE - COMMERCIAL', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;



insert into t_AllMaster values( @NextPKID,'71','RETAIL LICENCE - RESIDENTIAL','RETAIL LICENCE - RESIDENTIAL', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;



insert into t_AllMaster values( @NextPKID,'72','SETIA ECO PARK - D NETWORK','SETIA ECO PARK - D NETWORK', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;



insert into t_AllMaster values( @NextPKID,'73','GUL - COMMERCIAL','GUL - COMMERCIAL', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;



insert into t_AllMaster values( @NextPKID,'74','SETIA ECO PARK - D NETWORK','SETIA ECO PARK - D NETWORK', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;



insert into t_AllMaster values( @NextPKID,'75','SETIA CITY MALL','SETIA CITY MALL', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;




insert into t_AllMaster values( @NextPKID,'76','RN - RESIDENTIAL','RN - RESIDENTIAL', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;





insert into t_AllMaster values( @NextPKID,'77','RN - COMMERCIAL','RN - COMMERCIAL', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;








insert into t_AllMaster values( @NextPKID,'78','TASEK CENTRAL MALL','TASEK CENTRAL MALL', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;




insert into t_AllMaster values( @NextPKID,'A','RESIDENTIAL','RESIDENTIAL', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;




insert into t_AllMaster values( @NextPKID,'A1','GUL RESIDENTIAL','GUL RESIDENTIAL', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;



insert into t_AllMaster values( @NextPKID,'A2','SOLARIS DUTAMAS','SOLARIS DUTAMAS', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;




insert into t_AllMaster values( @NextPKID,'B','COMMERCIAL','COMMERCIAL', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;





insert into t_AllMaster values( @NextPKID,'B1','GUL COMMERCIAL','GUL COMMERCIAL', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;



insert into t_AllMaster values( @NextPKID,'B2','SOLARIS DUTAMAS','SOLARIS DUTAMAS', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;




insert into t_AllMaster values( @NextPKID,'B3','MIX DEVELOPMENT','MIX DEVELOPMENT', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;

insert into t_AllMaster values( @NextPKID,'P','MIX DEVELOPMENT','MIX DEVELOPMENT', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;



insert into t_AllMaster values( @NextPKID,'20','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'22','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'24','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'25','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'30','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'31','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'32','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'33','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'34','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'35','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'36','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'39','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'42','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'43','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'44','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'13','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'19','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'21','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'23','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'37','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;


insert into t_AllMaster values( @NextPKID,'38','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;






insert into t_AllMaster values( @NextPKID,'na','na','not available', @master_type,1,@Company_ID,@CreatedDate,@CreatedBy,0,1,@ApprovedDate,@ApprovedBy,@RejectionRemark,@isResubmit)

 SELECT @NextPKID = ISNULL(MAX(PKID), 0) + 1 FROM t_AllMaster;