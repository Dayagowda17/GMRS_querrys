DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 0;
DECLARE @RDGSTAT TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


INSERT INTO @RDGSTAT
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Meter Reading Status')

------Insert into t_BillMeterReading

select TOP 10 

BILMTRHISTNUM as PKID,
 BILNUM  as BILLNUM,
--tm.PKID as MeterNum,
null as  MeterNum,
MTRSEQNUM as MeterSequence,
LSTRDG as LastReading,
CURRDG as CurrentReading,
CONS as Consumption,
REPCONS AS RepConsumption,

(SELECT [PKID] FROM @RDGSTAT  WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(RDGSTAT)) AS 'MeterRdgStatus', 
TEMPERATURE AS TEMPERATURE,
tbm.PRESSURE AS PRESURE,
tbm.ZFACTOR AS ZFACTOR,
tbm.CFFACTOR AS CFFACTOR,
MMBTU AS MMBTU,
ROWID AS ROWID,
 @ModifiedDate AS LastUpdateDate,
@ModifiedBy LastUpdateUser,
@isActive AS LegacyFlag,

(SELECT [PKID] FROM @RDGSTAT  WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(RDGSTAT)) AS 'MeterRdgStatus'

from GMRS_August2025.dbo.TBBILMTRHIST tbm 
--join t_meterdetail tm
--on tbm.MTRNUM COLLATE SQL_Latin1_General_CP1_CI_AS=tm.MeterNum COLLATE SQL_Latin1_General_CP1_CI_AS

--select count(*)from  GMRS_August2025.dbo.TBBILMTRHIST 

--select top 10 * from  GMRS_August2025.dbo.TBBILMTRHIST 


--select count(*) from t_BillMeterReading


select top 10  tbr.billnum,tbm.BILNUM,tm.MeterNum ,tm.pkid,tbr.pkid,tbr.MeterNum

--update  tbr  set tbr.MeterNum=tm.pkid

from GMRS_August2025.dbo.TBBILMTRHIST tbm ,
t_billmeterReading tbr  
--join t_meterdetail tm
--on tbm.MTRNUM COLLATE SQL_Latin1_General_CP1_CI_AS=tm.MeterNum COLLATE SQL_Latin1_General_CP1_CI_AS
, t_meterdetail tm
where tbm.bilnum=tbr.billnum and tbm.MTRNUM COLLATE SQL_Latin1_General_CP1_CI_AS=tm.MeterNum COLLATE SQL_Latin1_General_CP1_CI_AS

select top 10 * from t_BillMeterReading
