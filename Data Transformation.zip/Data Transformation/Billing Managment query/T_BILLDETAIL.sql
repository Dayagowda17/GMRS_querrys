
 DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 0;
---Billdetails table query
DECLARE @CurrentMaxPKID INT = ISNULL((SELECT MAX(PKID) FROM t_BillDetail), 0);


DECLARE @TARCOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );



DECLARE @EventTypeGroupId TABLE (
    [PKID] INTEGER PRIMARY KEY,
    [Code] NVARCHAR(MAX),
    [EventGroup] NVARCHAR(MAX)
);




DECLARE @TARTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @TAXCOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @EVNCOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


INSERT INTO @TARCOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='TARIFF CODE')


INSERT INTO @EventTypeGroupId
SELECT PKID, Code, EventGroup  FROM EventTypeGroupControlTemp;





INSERT INTO @TARTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='TARIFF TYPE')




INSERT INTO @TAXCOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='TAX CODE')


INSERT INTO @EVNCOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Event Code Control')






--SELECT  FROM TBBILITMHIST
--insert into T_BILLDETAIL

SELECT  TOP 100
 ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) + @CurrentMaxPKID AS PKID,
bilnum as BillNum,
BILITMNUM as BillItemNum,

(SELECT [PKID]
        FROM @EventTypeGroupId
        WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(EVNTYP)
          AND [EventGroup] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(EVNGRP) )as 'EVENTTYPEGROUPID',

(SELECT [PKID] FROM @TARTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(TARTYP)) AS 'TARIFF TYPE', 



(SELECT [PKID] FROM @TARCOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(TARCOD)) AS 'TARIFF CODE', 



ITMDESCR as ItemDescription,
ITMQTY as ItemQuantity,
ITMRATE as ItemRate,
ITMPRC as ItemAmount,
A.GSTRATE as GSTRate,
GSTAMT as GSTAmount,
DODAT as DODate,


(SELECT [PKID] FROM @TAXCOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(TARTYP)) AS 'TAX CODE', 
@ModifiedDate as LastUpdateDate,
@ModifiedBy as LastUpdateUser,
@isDefault as LegacyFlag,




(SELECT [PKID] FROM @EVNCOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(EVNCOD)) AS 'EVENT CODE' 



from GMRS_August2025.dbo.TBBILITMHIST a,T_BILL B WHERE A.BILNUM=B.PKID AND   YEAR(B.BILLDATE )BETWEEN  2001 and 2003;





---select * from t_billdetail
--update tb set tb.TariffCode=t.tariffcode
--from t_bill tb join t_BillDetail t on tb.PKID=t.BillNum




