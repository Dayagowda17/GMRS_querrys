 executeing   this queery  ->reason beacuse user data not avialbe user table-----------------


Declare @CompanyID int=98;

Declare @Createdby int=90;

Declare @modifiedby int=90;
declare @isActive bit=0;
Declare @servicelocation int=10268;
DECLARE @password VARCHAR(255) = 'bO2iB1Gtj/wmWls9u38d9w==';
Declare @createddate date =getdate();
Declare @modifieddate date =getdate();
WITH DistinctUsers AS (
    SELECT DISTINCT a.USRID
    FROM gmrssep2025.dbo.TBBILL a
    LEFT JOIN gmrssep2025.dbo.TBUSER b 
        ON a.USRID = b.USRID
    WHERE b.USRID IS NULL
)
--INSERT INTO T_USER (PKID, UserName, Password,CompanyID,Firstname,createdby)
SELECT 
    ROW_NUMBER() OVER (ORDER BY (SELECT 1)) + 423 AS PKID,
    USRID,
    @password AS Password,
	 @CompanyID as companyid,
	 usrid as Firstname,
	 @Createdby as createdby,
	 @modifiedby as modifiedby,
	 @createddate as createddate,
	 @modifieddate as modifieddate,
	 @isActive as isactive
FROM DistinctUsers;

CREATE THE TWO USERS
IBCCS2
IBCCS3

----------------------case2-------------------------------------------------------------------------------

---  CASE   0 1 2 & 4 Should INSERT THE DATA INTO T_BILLTAX TABLE   evntyp in(0,1,2,4) and evngrp=80

--case other than evntyp=3 and evngrp=80 insert the data into t_bil
SELECT TOP 10 * FROM TBBILL A WHERE EVNTYP!='3' AND EVNGRP='80'AND EXISTS (SELECT * FROM TBOPITEMS B WHERE A.BILNUM=B.BILNUM) ---  CASE   0 1 2 & 4 SHOULd INSERT THE DATA INTO T_BILLTAX TABLE  





----------------------------------------------------------------------------------------------------------------------------------


DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 1;
DECLARE @WTARCOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );
DECLARE @ADJREACOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @EventTypeGroupId TABLE (
    [PKID] INTEGER PRIMARY KEY,
    [Code] NVARCHAR(MAX),
    [EventGroup] NVARCHAR(MAX)
);

DECLARE @CNTRCTIND TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );



DECLARE @RDGSTAT TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @RDGTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );



DECLARE @ACCTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );



DECLARE @USRID TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [UserName] NVARCHAR(MAX)
    );


DECLARE @POSIND TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );



DECLARE @PRNSTA TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @TAXCODE TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );



INSERT INTO @WTARCOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='TARIFF CODE')


INSERT INTO @EventTypeGroupId
SELECT PKID, Code, EventGroup  FROM EventTypeGroupControlTemp;


-- Populate variables

INSERT INTO @ADJREACOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Adjustment Reason')

INSERT INTO @CNTRCTIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Contract Ind')


INSERT INTO @RDGSTAT
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='meter Reading Status')



INSERT INTO @ACCTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Control Account Type')


INSERT INTO @RDGTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Bill Reading Type')

INSERT INTO @POSIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Post Ind')


INSERT INTO @PRNSTA
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='PRINT STATUS')



INSERT INTO @USRID
select PKID,UserName from t_User



INSERT INTO @TAXCODE
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Tax Code')
--INSERT INTO T_BILL
SELECT  top 100
    bilnum AS Pkid,
    CONNUM AS ConsumerNum,
    (SELECT [PKID]
        FROM @EventTypeGroupId
        WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(EVNTYP)
          AND [EventGroup] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(EVNGRP) )as 'EVENTTYPEGROUPID',

    null as Tarifftype,

(SELECT [PKID] FROM @WTARCOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(WTARCOD)) AS 'TARIFF CODE', 

(SELECT [PKID] FROM @ADJREACOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(ADJREACOD)) AS 'Adjustment Reason', 


    FINHISDAT AS FINHistDate,
    BILDAT AS BillDate,
    ARREARS AS Arrears,
    LSTBILDAT AS LastBillDate,
    LSTBILNUM AS LastBillNum,
    LSTBILAMT AS LastBillAmount,
    LSTPAYDAT AS LastPaymentDate,
    LSTPAYNUM AS LastPaymentNum,
    LSTPAYAMT AS LastPaymentAmount,
    PAYDUEDATE AS PaymentDueDate,
(SELECT [PKID] FROM @RDGTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(RDGTYP)) AS 'Bill Reading Type', 
(SELECT [PKID] FROM @RDGSTAT WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(RDGSTAT)) AS 'READING STATUS', 


CURBILAMT AS CurrentBillAmount,
(SELECT [PKID] FROM @POSIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(POSIND)) AS 'POST INDIACTOR', 


    DEPAMT AS DepositAmount,
    REFDEPAMT AS RefundDepositAmount,
    WADJAMT AS AdjustmentAmount,
(SELECT [PKID] FROM @USRID WHERE [UserName] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(USRID)) AS 'METER READER ID',

null as CreatedByUserId,    
BILREFNUM AS RefBillNum,
null as BillInd,
PRVBILDAT AS PreviousBillDate,
    CV AS CV,
    SPI AS SPI,
    ENTDAT AS EnteredDate,
    INSTALAMT AS InstallationAmount,
    INSPECAMT AS InspectionAmount,
    RECONAMT AS ReconnectionAmount,
    BILRAT AS BillRate,
    ROWID AS RowID,
    PROVISIONRATE AS ProvisionRate,
    GSTAMT as GSTAmount,
    GSTRATE as GSTRate,
    TAXINVNO as TaxInvoiceNum,
    GSTADJAMT as GSTAdjAmount,


(SELECT [PKID] FROM @TAXCODE WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(TAXCODE)) AS 'TAX CODE', 
    
    TAXABLEAMT as TAXABLEAMT,
    DISCBILIND as DisconBillInd,
    GCPT as GCPTAmount,
    SUBSIDY as SubsidyAmount,
CONCAT(ZONNUM, BLKNUM, ROUNUM) AS BookNum,

(SELECT [PKID] FROM @ACCTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(ACCTYP)) AS 'ACCOUNT TYPE', 

RLICCONNUM as LicenseeConsNum,
FIXEDFEE as FixedFeeAmount,
null as FixedFeeCalcType,
null as FixedFeeCalcRate,
SVCBILNUM as ServiceBillNum,
DISCOUNTAMT as DiscountAmount,
null as DiscountCalcType,
null as DiscountCalcRate,
null as CommissionRate,

(SELECT [PKID] FROM @CNTRCTIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(CNTRCTIND)) AS 'Contract Ind', 

null as SuspectRdgInd,



(SELECT [PKID] FROM @PRNSTA WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(PRNSTA)) AS 'Print Status', 

EXPSTA as ExportStatus,
getdate() as LastUpdateDate,
@ModifiedBy  as LastUpdateUser ,
@isDefault as LegacyFlag,
@isActive as IsActive,
null as AddlDepositAmt



FROM GMRS_june2025.dbo.TBBILL a
JOIN EventTypeGroupControlTemp b 
  ON a.evntyp COLLATE SQL_Latin1_General_CP1_CI_AS = b.Code COLLATE SQL_Latin1_General_CP1_CI_AS
 AND a.evngrp COLLATE SQL_Latin1_General_CP1_CI_AS = b.EventGroup COLLATE SQL_Latin1_General_CP1_CI_AS WHERE   	YEAR(BILDAT) between 1900 and 2000

