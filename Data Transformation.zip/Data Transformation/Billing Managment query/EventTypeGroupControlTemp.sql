
-- Create temporary table
CREATE TABLE EventTypeGroupControlTemp (
    PKID INT,
    Code VARCHAR(50),
    EventGroup VARCHAR(50)
);

-- Insert data into temporary table
INSERT INTO EventTypeGroupControlTemp (PKID, Code, EventGroup)
SELECT 
    a.PKID,
    b.Code,
    a.EventGroup
FROM 
    t_EventTypeGroupControl a
JOIN t_AllMaster b ON a.EventType = b.PKID
JOIN t_AllMasterType c ON b.MasterType = c.PKID
WHERE 
    c.Name = 'Event Type';

    SELECT * FROM EventTypeGroupControlTemp;

