
DECLARE @NextPKID INT;
DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @LastupdatedDate DATETIME = GETDATE();
DECLARE @LastupdatedBy INT = 90;
DECLARE @ModifiedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;


DECLARE @EVNCOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );
        INSERT INTO @EVNCOD
    select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Event Code Control')

--insert into t_eventcodecontrol
select ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID,
CASE
    WHEN EVNCOD = '00' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '00' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '01' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '01' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '02' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '02' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '03' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '03' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '04' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '04' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '05' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '05' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '06' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '06' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '07' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '07' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '08' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '08' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '11' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '11' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '13' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '13' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '14' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '14' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '15' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '15' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '16' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '16' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '17' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '17' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '18' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '18' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '21' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '21' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '22' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '22' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '23' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '23' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '50' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '50' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '60' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '60' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '70' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '70' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '80' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '80' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '90' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '90' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
    WHEN EVNCOD = '99' THEN (SELECT PKID FROM t_AllMaster WHERE Code = '99' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Event Code Control'))
END AS EventCode,

CONTRAIND AS ContraInd,
SUSPEND AS IsSuspended,
@LastupdatedBy AS lASTUPDATEDBY,
  @LastupdatedDate AS LASTUPDATEDDATE,
1 AS LEGACYFLAG

FROM GMRS_August2025.DBO.TBEVNCOD
