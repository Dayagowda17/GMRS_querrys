	DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 0;
DECLARE @ADJREACOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @EventTypeGroupId TABLE (
    [PKID] INTEGER PRIMARY KEY,
    [Code] NVARCHAR(MAX),
    [EventGroup] NVARCHAR(MAX)
);


DECLARE @CNCTRIND TABLE (
    [PKID] INTEGER PRIMARY KEY,
    [Code] NVARCHAR(MAX),
    [EventGroup] NVARCHAR(MAX)
);






DECLARE @RDGTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );





DECLARE @DRCRIND TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @OPSTAT TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );



DECLARE @FIFOIND TABLE (
         [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @TAXCODE TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );



DECLARE @INVIND TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @INVIND TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );









INSERT INTO @EventTypeGroupId
SELECT PKID, Code, EventGroup  FROM EventTypeGroupControlTemp;


-- Populate variables

INSERT INTO @ADJREACOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Adjustment Reason')



INSERT INTO @CNCTRIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Contract Ind')



INSERT INTO @RDGTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Reading Type')




INSERT INTO @DRCRIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Debit Credit Ind')

INSERT INTO @OPSTAT
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Open Item Status')


INSERT INTO @FIFOIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Open Item Status')



INSERT INTO @TAXCODE
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='TAX CODE')



INSERT INTO @INVIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Open Item Invoice Indicator')






---------------------open item -------------------------------

--select * ---delete from t_OpenItem
---insert into t_openitem
select TOP 100
OPNUM AS PKID,

 CONNUM as ConsumerNum,
 BILNUM as BillNum,
 paynum as PaymentNum,
     (SELECT [PKID]
        FROM @EventTypeGroupId
        WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(EVNTYP)
          AND [EventGroup] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(EVNGRP) )as 'EVENTTYPEGROUPID',



(SELECT [PKID] FROM @ADJREACOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(ADJREACOD)) AS 'ADJReasonCode', 



APPDAT as AppDate,
ENTDAT as EnteredDate,
POSDAT as PostedDate,

(SELECT [PKID] FROM @RDGTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(RDGTYP)) AS ' Reading Type ', 


REJIND as RejectInd,

(SELECT [PKID] FROM @DRCRIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(DRCRIND)) AS ' DEBOT CREADIT IND ', 

 OPAMT as OpenItemAmount,

 
(SELECT [PKID] FROM @OPSTAT WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(OPSTAT)) AS 'OPEN ITEM STAT ', 

OFFSETDAT as OffsetDate,
DocNum as DocNum,
@CreatedBy as Origin,
CONS as Consumption,
FIFOOSBALAMT as FIFOOSBalAmount,

(SELECT [PKID] FROM @FIFOIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(FIFOIND)) AS 'FIFO INDICATOR', 



GSTAMT as GSTAmount,
GSTRate as GSTRate,
TAXINVNO as TaxInvoiceNum,
GSTADJAMT as GSTAdjAmount,


(SELECT [PKID] FROM @TAXCODE WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(TAXCODE)) AS 'TAX CODE', 


TAXABLEAMT as TaxableAmount,
DROPNUM as DropNum,
GCPT as GCPT,



(SELECT [PKID] FROM @INVIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(INVIND)) AS ' Open Item Invoice Indicator ', 


RLPAYIND as RLPayInd,

(SELECT [PKID] FROM @CNTRCTIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(CNTRCTIND)) AS 'CONTRACT IND ',
@ModifiedDate as LastUpdateDate ,
@ModifiedBy as LastUpdateUser,
@isActive as LegacyFlag,
OFFBALAMT as OffsetBalAmount, 
REVIND  as RevInd

 FROM GMRS_August2025.dbo .tbopitems where year(ENTDAT) between 2016 and 2018


--
