DECLARE @isActive BIT=1;
DECLARE @ApprovedBy INT=90;
DECLARE @Company_ID INT=98;
DECLARE @CreatedDate DATETIME=GETDATE();
DECLARE @CreatedBy INT=90;
DECLARE @ModifiedBy INT=90;
DECLARE @ModifiedDate DATETIME=GETDATE();
DECLARE @ServiceLocation INT=10268;






--INSERT INTO t_WOSiteInspection
 SELECT  
 ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID,
 WONUM AS WORKORDERNUM,
 CONCAT(ZONNUM,BLKNUM,ROUNUM) AS BOOKNO,
 CNNPIPSIZ AS CnnPipeSize,
 CNNPIPQTY AS CnnPipeQty ,
 CNNPIPRATE AS CnnPipeRate,
 FERSIZ AS FerSize,
 FERQTY AS FerQty,
 FERRAT  AS FerRate,
 SADSIZ AS SadSize,
 SADQTY AS SadQty,
 SADRAT AS SadRate,
 SURRAT AS SurRate,
 SURLEN AS SurLength,
 DIGRAT AS DigRate,
 DIGLEN AS Diglength,
 CNNPRC AS CnnPrice,
 ESTDAIUSE  AS EstdAIUse,
 RDGSEQ AS RdgSequence,
 @CreatedDate AS LastUpdateDate,
@CreatedBy  AS LastUpdateUser,
@isActive AS LegacyFlag
FROM GMRS_JUNE2025.DBO.TBWOSITEINSP

