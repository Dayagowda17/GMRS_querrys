DECLARE @isActive BIT=1;
DECLARE @ApprovedBy INT=90;
DECLARE @Company_ID INT=98;
DECLARE @CreatedDate DATETIME=GETDATE();
DECLARE @CreatedBy INT=90;
DECLARE @ModifiedBy INT=90;
DECLARE @ModifiedDate DATETIME=GETDATE();
DECLARE @ServiceLocation INT=10268;

DECLARE @MTRSIZ  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @MTRTYP  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

          DECLARE @MEATYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

     DECLARE @UOM TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


    
      DECLARE @DIALLEN TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

        DECLARE @MTRBRAND TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

    DECLARE @DISCONACT TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );



    INSERT INTO @MTRSIZ
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Meter Size')
    INSERT INTO @MTRTYP 
    select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Meter Type')
         INSERT INTO @MEATYP
    select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Measure Type')

       INSERT INTO @MTRBRAND
    select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Meter Brand')

        INSERT INTO @UOM
    select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Meter UOM')


            INSERT INTO @DIALLEN
    select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Meter Dial Length')


            INSERT INTO @DISCONACT
    select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Disconnection Action')
insert into t_WOMeterChange
SELECT top 10
 ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID,
 WONUM AS WORKORDERNUM,
NULL AS OldMeterNum,
 MTRSEQNUM AS MeterSequenceNum,

(SELECT [PKID] FROM @MTRSIZ WHERE [Name] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(OLDMTRSIZ)) AS 'Old Meter Size',
(SELECT [PKID] FROM @MTRTYP WHERE [Name] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(OLDMTRTYP)) AS 'Old Meter Type',
(SELECT [PKID] FROM @MEATYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(OLDMEATYP)) AS 'Old Measure Type',
(SELECT [PKID] FROM @UOM WHERE [code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(OLDUOM)) AS 'Old UOM',

(SELECT [PKID] FROM @DIALLEN WHERE [code] COLLATE SQL_Latin1_General_CP1_CI_AS =OLDDIALLEN) AS 'Old DIAL LENGTH',
NULL AS OldMeterLOC,
OLDAVGCONS AS OldAvgConsumption,
OLDPRVCONS AS OldPrvConsumotion,
 
OLDLSTRDGDAT AS OldLastRdgDate,
 
OLDLSTRDG AS OldLastRdg,

CURRDG AS CurrentRdg,
NULL  AS NewMeterNum,
 (SELECT [PKID] FROM @MTRSIZ WHERE [Name] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(NEWMTRSIZ)) AS 'New Meter Size',
(SELECT [PKID] FROM @MTRTYP WHERE [Name] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(NEWMTRTYP)) AS 'New Meter Type',
(SELECT [PKID] FROM @MEATYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(NEWMEATYP)) AS 'New Measure Type',
(SELECT [PKID] FROM @UOM WHERE [code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(NEWUOM)) AS 'New UOM',
(SELECT [PKID] FROM @MTRBRAND WHERE [Name] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(NEWMTRBRAND)) AS 'New Meter Brand',
NEWPURCDAT AS NewPurchaseDate,

(SELECT [PKID] FROM @DIALLEN WHERE [code] COLLATE SQL_Latin1_General_CP1_CI_AS =NEWDIALLEN) AS 'New DIAL LENGTH',
NEWMTRLOC AS NewMeterLOC,
INIRDG AS InitialRdg,

(SELECT [PKID] FROM @DISCONACT WHERE [code] COLLATE SQL_Latin1_General_CP1_CI_AS =TRIM(DISCONACT)) AS 'DisconAct',
DISCONIDX AS DisconIdx,
OLDRDGSEQ AS OldRdgSeq,
ISFAULTY AS IsFaulty,
@CreatedDate AS LastUpdateDate,
@CreatedBy AS LastUpdateUser,
@ISACTIVE AS LegacyFlag
FROM GMRSSep2025.DBO.TBWOMTRCHG A



/*JOIN T_METERDETAIL MD 
  ON A.OLDMTRNUM COLLATE SQL_Latin1_General_CP1_CI_AS = MD.METERNUM
 AND A.NEWMTRNUM COLLATE SQL_Latin1_General_CP1_CI_AS = MD.METERNUM








