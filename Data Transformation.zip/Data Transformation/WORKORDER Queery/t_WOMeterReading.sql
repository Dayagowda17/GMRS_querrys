DECLARE @isActive BIT=1;
DECLARE @ApprovedBy INT=90;
DECLARE @Company_ID INT=98;
DECLARE @CreatedDate DATETIME=GETDATE();
DECLARE @CreatedBy INT=90;
DECLARE @ModifiedBy INT=90;
DECLARE @ModifiedDate DATETIME=GETDATE();
DECLARE @ServiceLocation INT=10268;
DECLARE @MEATYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @UOM TABLE (
   [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @DIALLEN  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @RDGTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );



INSERT INTO @MEATYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='MEASURE TYPE')

PRINT '**INSERTING ZONE RECORDS INTO TEMP TABLE**'


INSERT INTO @UOM
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='METER UOM')

PRINT '**INSERTING ZONE RECORDS INTO TEMP TABLE**'

INSERT INTO @DIALLEN
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='METER Dial length')

PRINT '**INSERTING BLOCK RECORDS INTO TEMP TABLE**'

INSERT INTO @RDGTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Bill Reading Type')











--INSERT INTO t_WOMeterReading
 SELECT  
 ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID,
 WONUM AS WORKORDERNUM,
 B.PKID AS MeterNum,
-- A.MTRNUM, VALIDATION PURPOSE
 --B.MeterNum,

 MTRSEQNUM  AS MeterSequenceNum,



 (SELECT [PKID] FROM @MEATYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(A.MEATYP)) AS 'MEAUSRE TYPE', 
 (SELECT [PKID] FROM @UOM WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(A.UOM)) AS 'Meter UOM', 
   (SELECT [PKID] FROM @DIALLEN WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = A.DIALLEN) AS 'DIAL LENGTH', 

LSTRDGDAT AS LASTRDGDAT,
LSTRDG AS LSTRDG,
CURRDG AS CurrentRdg,
(SELECT [PKID] FROM @RDGTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(RDGTYP)) AS 'READING TYPE', 
RDGSEQ AS RDGSEQUENCE,
@CREATEDDATE AS LastUpdateDate,
@CREATEDBY AS LastUpdateUser,
@ISACTIVE AS LEGACYFLAG


FROM GMRS_june2025.DBO.TBWOMTRRDG A
JOIN t_MeterDetail B 
    ON A.MTRNUM COLLATE SQL_Latin1_General_CP1_CI_AS = B.MeterNum



 SELECT TOP 10 *FROM t_WOMeterReading
