DECLARE @isActive BIT=1;
DECLARE @ApprovedBy INT=90;
DECLARE @Company_ID INT=98;
DECLARE @CreatedDate DATETIME=GETDATE();
DECLARE @CreatedBy INT=90;
DECLARE @ModifiedBy INT=90;
DECLARE @ModifiedDate DATETIME=GETDATE();
DECLARE @ServiceLocation INT=10268;
DECLARE @LEGACY BIT=1;


DECLARE @COLAGT TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );
DECLARE @PAYTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @USRID TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [UserName] NVARCHAR(MAX)
    ); 



DECLARE @EventTypeGroupId TABLE (
    [PKID] INTEGER PRIMARY KEY,
    [Code] NVARCHAR(MAX),
    [EventGroup] NVARCHAR(MAX)
);   
    
DECLARE @TAXCODE TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );
    
INSERT INTO @COLAGT
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='AGENT CODE')

    
    
INSERT INTO @PAYTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='BILL PAYMENT TYPE')

INSERT INTO @USRID
select PKID,UserName from t_User

INSERT INTO @EventTypeGroupId
SELECT PKID, Code, EventGroup  FROM EventTypeGroupControlTemp;
INSERT INTO @TAXCODE
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='TAX CODE')


 SELECT   TOP 1000
 
PAYNUM AS PKID,
BATCHNUM AS PAYMENTBATCHID,
CONNUM AS CONSUMERNUM
(SELECT [PKID] FROM @COLAGT WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(COLAGT)) AS 'COLLECTION AGNET',
(SELECT [PKID] FROM @PAYTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(PAYTYP)) AS 'PAYMENT TYPE',
PAYAMT AS PAYMENTAMOUNT,
NULL AS POSTIND,
NULL AS REVENUECODE,
RCPNUM AS RECEIPTNUM,
BATCHREF AS BATCHREF,
NULL AS SOURCEBRANCH,
APPDAT AS APPIDATE,
@USRID AS  ENETERDBYUSERID,
ENTDAT AS ENETEREDDATE,
POSDAT AS POSTDATE,
@ISACTIVE AS ISACTIVE,
@LEGACY AS Legacy
NULL AS EventTypeGroupControlId,
NULL AS ReferenceIdentifier

FROM GMRS_JUNE2025.DBO.TBNONBILLPAYMENT

