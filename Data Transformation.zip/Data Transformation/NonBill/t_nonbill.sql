DECLARE @isActive BIT=1;
DECLARE @ApprovedBy INT=90;
DECLARE @Company_ID INT=98;
DECLARE @CreatedDate DATETIME=GETDATE();
DECLARE @CreatedBy INT=90;
DECLARE @ModifiedBy INT=90;
DECLARE @ModifiedDate DATETIME=GETDATE();
DECLARE @ServiceLocation INT=10268;


DECLARE @TARCOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );
DECLARE @POSIND TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @USRID TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [UserName] NVARCHAR(MAX)
    ); 



DECLARE @EventTypeGroupId TABLE (
    [PKID] INTEGER PRIMARY KEY,
    [Code] NVARCHAR(MAX),
    [EventGroup] NVARCHAR(MAX)
);   
    
DECLARE @TAXCODE TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );
    
INSERT INTO @TARCOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Tariff Code')

    
    
INSERT INTO @POSIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='POST IND')

INSERT INTO @USRID
select PKID,UserName from t_User

INSERT INTO @EventTypeGroupId
SELECT PKID, Code, EventGroup  FROM EventTypeGroupControlTemp;
INSERT INTO @TAXCODE
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='TAX CODE')


insert into t_NonBill

 SELECT   
 
 ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID,
 BILDAT AS BILLDATE,

     (SELECT [PKID]
        FROM @EventTypeGroupId
        WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(EVNTYP)
          AND [EventGroup] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(EVNGRP) )as 'EVENTTYPEGROUPID',
(SELECT [PKID] FROM @TARCOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(WTARCOD)) AS 'Tariff code',
CURBILAMT AS BillAmount,

(SELECT [PKID] FROM @POSIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(POSIND)) AS 'POST INDICATOR',

(SELECT [PKID] FROM @USRID WHERE [USERNAME] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(USRID)) AS 'CREATED BY', 

GSTRATE AS GSTRATE,
GSTAMT AS GSTAMOUNT,
NULL AS AMOUNT,


(SELECT [PKID] FROM @TAXCODE WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(TAXCODE)) AS 'TAX CODE',

@CreatedDate AS LastUpdateDate,
(SELECT [PKID] FROM @USRID WHERE [USERNAME] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(USRID)) AS 'LastUpdateUser', 
@isActive AS LEGACYFLAG,
CONNUM AS CONSUMERNUM,
NULL AS PAIDAMOUNT,
null as balanceamount,
NULL AS NonBillOffsetStatus,
NULL AS OffsetDATE,
NULL AS FIFOOSBal,
NULL AS FIFOInd
FROM GMRSSep2025.DBO.TBNONBILL
where bilnum in(3967729 ,
3967734 ,
3967739 ,
3967740 ,
3967743 ,
3967745 ,
3967748 ,
3967757 ,
3967760 ,
3967764 
)

select top 10 * 
FROM GMRS_AUGUST2025.DBO.TBNONBILL



select * from t_allmastertype where name like 'ta%'

select * from  EventTypeGroupControlTemp where mastertype=558