DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 0;
DECLARE @Districtid INT = 121;
DECLARE @Itemsegment BIT = 1;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL = 0.00;
insert into t_routediscount
SELECT 
    ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID,
    ta.PKId AS RouteID,
    --ta.name,
    DISCOUNTAMT AS DiscountAmount,
    DISCOUNTSTADAT AS StartDate,
    DISCOUNTENDDAT AS EndDate,
    @isActive AS IsActive,
    @ModifiedDate AS ModifiedDate,
    @ModifiedBy AS ModifiedBy,
    @Company_ID AS CompanyID,
    @CreatedDate AS CreatedDate,
    @CreatedBy AS CreatedBy,
    @ServiceLocation AS ServiceLocation,
    @islegacyflag AS aslegacyflag,
    CASE
        WHEN DISCOUNTAMT = DISCOUNTAMT THEN (
            SELECT PKID 
            FROM t_AllMaster 
            WHERE Code = 'Discount Amount' 
              AND MasterType = (
                  SELECT PKID 
                  FROM t_AllMasterType 
                  WHERE Name = 'Discount Calculation Type'
              )
        )
    END AS CalculationType
FROM GMRS_june2025.dbo.tbroute tr
JOIN t_route ta 
  ON tr.DESCR COLLATE SQL_Latin1_General_CP1_CI_AS = ta.Name COLLATE SQL_Latin1_General_CP1_CI_AS
WHERE DISCOUNTAMT IS NOT NULL;
