
DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT=0;
DECLARE @ROUTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );
DECLARE @TARCOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

    DECLARE @ACCTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

        DECLARE @AREACOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


   DECLARE @AREAID TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [ZONNUM] NVARCHAR(MAX),
        [BLOCKNUM] NVARCHAR(MAX)
    );

INSERT INTO  @ROUTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Route Type')

INSERT INTO  @TARCOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Tariff Code')


INSERT INTO  @ACCTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Supply by Account Type')



INSERT INTO  @AREACOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Route Geo Area Code')




INSERT INTO  @AREAID
select PKID,ZONNUM,BLOCKNUM from T_REP_AREATEMP



insert into t_route
SELECT 
    ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID, 
    DESCR AS NAME,
    @isActive AS ISACTIVE,
    @ServiceLocation AS SERVICELOCATION,
    @Company_ID as COMPANYID,
    @CreatedDate  AS CREATEDDATE, 
   @CreatedBy AS CreateBy,                       
   @ModifiedBy  AS ModifiedBy,  
    @ModifiedDate AS MODIFIEDDATE,
  (
       SELECT  PKID
       FROM @AREAID ai
       WHERE ai.ZONNUM COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(A.ZONNUM) COLLATE SQL_Latin1_General_CP1_CI_AS
         AND ai.BLOCKNUM COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(A.BLKNUM) COLLATE SQL_Latin1_General_CP1_CI_AS
    ) AS AREAID,



(SELECT [PKID] FROM @ROUTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(ROUTYP)) AS 'Route Type',
null as code,

(SELECT [PKID] FROM @TARCOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(TARCOD)) AS 'Tariff Code',


(SELECT [PKID] FROM @ACCTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(ACCTYP)) AS 'SUPPLY BY ACCOUNT TYPE',
RLICCONNUM AS SUPPLYBYCONSNUM,
NULL AS RouteSalesPersonID,
COMMRAT AS  CommissionRate,
GASCOMDATE AS CommissionDate,
NULL AS ScheduleDate,
ENDUSER AS EndUserCount,
FITUNIT  AS FitUnitCount,
NULL AS Remarks,
LANDEDPROP AS LandedProperty,
JDECONNUM AS JDEConsNum,
0 AS DiscountInd,
1 AS LegacyFlag,
AUTOCONADD2 AS Address2,
AUTOCONADD3 AS Address3,
AUTOPOSCOD as Pincode,
concat(a.ZONNUM,BLKNUM,ROUNUM) as BookNo,
NULL as ConsumerPremiseType,
NULL AS DepositAmount,
NULL AS InstallationAmount,
NULL AS MeterPurchaseAmount,
NULL AS StampingFee,
NULL AS CityGate,
NULL AS CV,
NULL as RequireInstallationAmount,
NULL as RequireMeterPurchaseAmount,
NULL as RequireStampingFee,
NULL as RequireDepositAmount,
NULL as RequireMeterRental,
NULL as MeterRental,
NULL as RepId,
NULL as BillingCompany, --t_billingcompany [lP-GAS MALAYSIA ENERGY AND SERVICES S/B and not in LP--GAS MALAYSIA RETAIL SERVICES SDN BHD]
 

(SELECT [PKID] FROM @AREACOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(AREACOD)) AS 'Route Geo Area Code'

FROM GMRS.dbo.TBROUTE A
JOIN T_REP_AREATEMP B
    ON A.ZONNUM COLLATE SQL_Latin1_General_CP1_CI_AS = B.ZONNUM COLLATE SQL_Latin1_General_CP1_CI_AS
   AND A.BLKNUM COLLATE SQL_Latin1_General_CP1_CI_AS = B.BLOCKNUM COLLATE SQL_Latin1_General_CP1_CI_AS;




---------Billing company updation querry-----------------
UPDATE b
SET b.billingCompany = 
    CASE 
        WHEN am.Code COLLATE SQL_Latin1_General_CP1_CI_AS = 'LP' THEN 3
        ELSE 1
    END
FROM GMRS_June2025.dbo.TBROUTE a
JOIN t_route b 
    ON a.descr COLLATE SQL_Latin1_General_CP1_CI_AS = b.name COLLATE SQL_Latin1_General_CP1_CI_AS
JOIN t_AllMaster am 
    ON am.Code COLLATE SQL_Latin1_General_CP1_CI_AS = a.ACCTYP COLLATE SQL_Latin1_General_CP1_CI_AS
JOIN t_AllMasterType amt 
    ON am.MasterType = amt.PKID
WHERE amt.Name = 'Supply by Account Type';