DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT=0;
--DECLARE @stateid INT = 5271;
DECLARE @Districtid INT = 121;
--DECLARE @TalukID INT = 328;
----DECLARE @CountryID INT = 149;
DECLARE @Itemsegment BIT = 1;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL=0.00;




--insert into t_routecharge

select 
 ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID,
 case 
 when  
  FIXEDFEE=FIXEDFEE THEN (SELECT PKID FROM t_AllMaster WHERE Code = 'Service Charge' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Route Charge Code'))
  end as ChargeCode,

  CASE 
WHEN FIXEDFEE < 1.00 THEN  (SELECT PKID FROM t_AllMaster WHERE Code = 'Rate' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Calculation Type'))
  WHEN FIXEDFEE >= 1.00 THEN (SELECT PKID FROM t_AllMaster WHERE Code = 'Amount' AND MasterType = (SELECT PKID FROM t_AllMasterType WHERE Name = 'Calculation Type'))
  END AS ChargeCalcType,
FIXEDFEE as ChargeCalcValue,
MINUSAGE as ChargeMinQty,
null as ChargeMinAmount,
null as StartDate,
null as EndDate,
@isActive as isactive,
@ModifiedDate as ModifiedDate,
@ModifiedBy as ModifiedBy,
@Company_ID as CompanyID,
@CreatedDate as CreateDate,
@CreatedBy as CreateBy,
@ServiceLocation as ServiceLocation,
@islegacyflag as LegacyFlag,
NULL as RouteID,
@GSTRateIndicator as GSTRateIndicator,
@GSTPercentage as GSTPercentage
--MINUSAGE as MinUsage






from GMRS_june2025.dbo.tbroute

--update a set RouteID=a.pkid
from t_routecharge a,t_route b where a.pkid=b.pkid
