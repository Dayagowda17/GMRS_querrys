DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 0;
DECLARE @Districtid INT = 121;
DECLARE @Itemsegment BIT = 1;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL = 0.00;




-- insert into t_ConsumerGasLicenseContract

SELECT 
     ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID, 
    CONNUM AS ConsumerNum,
    CNTRCTNUMDEL as DeliveryContractNum,
     CDELIVERY as DeliveryContractFlag,
      CNTRCTNUMSVC as ServiceContractNum, 
      CSERVICE as ServiceContractFlag,
       null as FleetGroupFlag,
        MGMTFEE as ManagementFee,
        SVCCHRG as ServiceCharge,
        @isActive  as IsActive,
    @islegacyflag as LegacyFlag, 
    @CreatedBy AS CreateBy,
     LSTUPD as ModifiedDate, 
     @ModifiedBy AS ModifiedBy,
     @Company_ID AS company,
      @ServiceLocation AS servicelocation,
    @CreatedDate as createddate
FROM  GMRS_August2025.dbo.TBCONTRACT
