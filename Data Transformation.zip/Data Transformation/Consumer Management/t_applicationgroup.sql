DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 0;
DECLARE @Districtid INT = 121;
DECLARE @Itemsegment BIT = 1;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL = 0.00;

DECLARE @APPSTA  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @SITEIND  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @APRIND  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );



    DECLARE @INSBILIND  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


    DECLARE @APPBILIND  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


INSERT INTO @APPSTA
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Application Status')


INSERT INTO @SITEIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Site inspection status Indicator')



INSERT INTO @APRIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Site approval status Indicator')




INSERT INTO @INSBILIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Installtion bill status Indicator')




INSERT INTO @APPBILIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Application bill status Indicator')


--insert into t_ApplicationGroup


select 
  ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID ,
  CONNUM as ConsumerNum  ,
  GRPDESC as GroupDescription ,
  DEVNAM as DeveloperName ,
  DEVADD1 as DeveloperAddress1 ,
  DEVADD2 as DeveloperAddress2,
  DEVADD3 as DeveloperAddress3,

  (SELECT [PKID] FROM @APPSTA WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(APPSTA)) AS 'Application Status', 

INSBILDAT as InstBillDate,
PAYINSBILDAT as InstBillPayDate,
APPBILDAT as AppBillDate,
PAYAPPBILDAT as AppBillPayDate,
WOSTEINS as WOSteins,
@islegacyflag as LegacyFlag,
@CreatedBy as CreateBy, 
@ModifiedDate  as'modified date',
@ModifiedBy ModifiedBy ,
@Company_ID as Company,
@ServiceLocation as 'servicelocation',

  (SELECT [PKID] FROM @SITEIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(SITEIND )) AS 'Site inspection status Indicator', 
    (SELECT [PKID] FROM @APRIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(APRIND )) AS 'Site approval status Indicator', 

        (SELECT [PKID] FROM @INSBILIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(INSBILIND )) AS 'Installtion bill status Indicator', 


        (SELECT [PKID] FROM @APPBILIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(APPBILIND )) AS 'Application bill status Indicator'



from GMRS.dbo.TBNEWAPPGRP
