DECLARE @LANDEDPROP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );



DECLARE @ACCTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @CONTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @BILMOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @SUPPTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @WTARCOD  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @CONSTA TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @ANALYSIS2  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @ANALYSIS1  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @ANALYSIS3  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @INCOMELVL TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );
INSERT INTO @LANDEDPROP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Control Account Type')


INSERT INTO @ACCTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Control Account Type')


INSERT INTO @CONTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Consumer Type')


INSERT INTO @BILMOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Billing Mode')


INSERT INTO @SUPPTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Supply Type')


INSERT INTO @WTARCOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Tariff Code')


INSERT INTO @CONSTA
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Consumer Status')


INSERT INTO @ANALYSIS2
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Consumer Premise Type')


INSERT INTO @ANALYSIS1
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Occupancy Type')


INSERT INTO @ANALYSIS3
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Meter access type')


INSERT INTO @INCOMELVL
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Income Level')









DECLARE @isActive BIT = 1;
DECLARE @GroupID INT = 8;
DECLARE @isApproved BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @approvedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT=0;
DECLARE @stateid INT = 5271;
DECLARE @Districtid INT = 121;
DECLARE @TalukID INT = 328;
DECLARE @CountryID INT = 149;
DECLARE @IsTariffFromRLic BIT = 0;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL=0.00;
insert into t_party
select 
CONNUM as PKID,CONNAM as Code,
  @GroupID as GroupID,
  CONNAM as Name,
  CONADD1 as Address1,
  CONADD2 as Address2,
  CONADD3 as Address3,
  CONADD3 as city,
  poscod as PinCode,@CountryID as country,
  @stateid as state,
  null as GST,
  handphone as MobileNo,
  instphoneno as LandLine,
  null as DrugLicence1,
  null as DrugLicence2,
 @Districtid as district,
 null as area, 
 null as route ,
null as OpeningBalance,
null as ClosingBalance,
null as DoctorName,
null as KVCNo,
null as CreditLimit ,
null as CreditDays,
@ServiceLocation AS servicelocation ,
@Company_ID AS company,
@isActive as IsActive,
@ModifiedDate modifieddate,
@ModifiedBy AS ModifiedBy,
@CreatedDate CreateDate,
@CreatedBy AS CreateBy,
null as DrugLicenceExpiry,
null as RepID,
null as Discount,
null as PrintCopy,
EMAIl as Email
,null as ContactPerson,
null as MaximumLeadTime,
null as AverageLeadTime,
null as PartyType,
null as AdmissionNo,
null as SatsNo,
null as MotherName,
null as FatherName,
null as DOB,
null as Religion,
null as ReligionCode,
null as IsTCSApplicable,
null as ActingRole,
null as TrustActivity,
null as ClassGrade,
null as IsDefaultParty,
null as IsDefaultAccountParty,
null as PAN,
null as AccountGroupID,
null as DeficitNotificationChannel,
null as GenderType,
null as GenderType,
null as MenstruationDate,
null as MenstruationCyleDays
,null as MenstruationNotificationDate,
null as DrivingLicence,
null as BadgeNumber,
null as EmployeeNo,
null as BusinessBranch,
null as SecondaryEmail,
null as BankName,
null as AccountNo,
null as IFSCCode,
null as DrivingLicenceExpiry,
null as VehcileInsuranceExpiry,
null as VehcileEmissionExpiry,
null as VehcileFitnessExpiry,
null as RegNo,
null as Mileage,
null as TankCapacity,
null as OwnershipType,
@TalukID as TalukID,
null as RouteJunctionPoint,
null as WebSite,
null as LeadStatus,
null as HandledBy,
null as WonBy
,null as DealSize,
null as IndustrySegment,
null as EmployeeSize,
null as OrgType,
null as SourceInfo,
null as Revenue,
null as OrgBankName,
null as OrgBankIFSCCode,
null as OrgChequeName,
null as OrgBankAccountNumber,
null as NextActionDate,
null as CallStatus,
null as ProspectStatus,
null as FMCGArea,
null as FMCGCreditDays,
null as FMCGCreditLimit,
null as FMCGDiscount,
null as FMCGPrintCopy,
null as SaleInsight,
null as SchemeClass,
null as LegalName,
null as IsDefaultAccountElectronicFunds,
null as Designation,
null as Doctor,
null as Mark,
null as IsClaimApplicable,
null as IsItemTypeDiscountApplicable,
null as ProfileUrl,
null as OwnedBy,
null as CreditDaysInPrint,
null as FMCGCreditDaysInPrint,
null as TransportMode,
null as DeliveryMode,
null as IsDefaultAccountAmazonECommerceFunds,
null as IsDefaultAccountJIOECommerceFunds,
null as ReminderMeInDays,
null as AADHARNO,
null as OverAllDocumentStatus,
null as OverAllDocumentRemark ,
null as IsDefaultAccountComplementaryFunds,
null as 'ApplicationID',null as ReSubmitted ,
null as OverAllRemark,null as CscReceiptNo,
null as IsDefaultAccountInterBranchSalesFunds,
null as ConsiderChildOrdersWhileSaleBill,
null as IsFreshApplication,
null as SmsStatus,
null as IsDefaultAccountDamageFunds,
null as IsDefaultDebitAccountForDamageDisposal,
null as IsDefaultCreditAccountForDamageDisposal,
null as OrgName,
null as GSTRegistrationName
,null as CompanyRegNo,
RDGSEQ as 'SpotReadingSerial',
LSTRDGDAT as 'last reading date'
,SUPDAT 'as gas connection date',
null as ClearanceRemark,
CHKDIG as CheckDigit,


(SELECT [PKID] FROM @ACCTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(ACCTYP)) AS 'Control Account Type',
null as LicenseeConsumerNum ,

(SELECT [PKID] FROM @CONTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(CONTYP)) AS 'CONSUMER TYPE',
CONNAM as ConsumerName,
COMPNAM as CompanyName,
null as 'SSMNum',
NEWIC as NewICNo,
OLDIC as OldICNo,
PASSNO as PassportNo,
null as MobileNo1,
FAXNO as FaxNum, 
null as 'JDECONNUM write query for thisS column',
(SELECT [PKID] FROM @BILMOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(BILMOD)) AS 'Billing Mode',

CTRTDAT as GSARegDate,



(SELECT [PKID] FROM @SUPPTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(SUPPTYP)) AS 'Supply Type',



(SELECT [PKID] FROM @WTARCOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(WTARCOD)) AS 'TARIFF CODE',


(SELECT [PKID] FROM @CONSTA WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(CONSTA)) AS 'Consumer Status',



(SELECT [PKID] FROM @ANALYSIS2 WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(ANALYSIS2)) AS 'CONSUMER PREMISE TYPE',

null as CityGateCode,
null as CV,


(SELECT [PKID] FROM @ANALYSIS1 WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(ANALYSIS1)) AS 'Occupancy Type',



(SELECT [PKID] FROM @ANALYSIS3 WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(ANALYSIS3)) AS 'Meter access type',





Analysis4 as Analysis4,
Analysis5 as Analysis5,
LANDEDPROP as LandedProperty,
(SELECT [PKID] FROM @INCOMELVL WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(INCOMELVL)) AS 'Occupancy Type',


OCCUCNT as OccupancyCount,
CTRTNUM as ContractNum,
null as RequireAutoDebit,
null as RequireEInvoice,
null as IncomeTaxNumber,
null as SaleTaxNumber,
null as ServiceTaxNumber,
null as BankID,
null as NeedToBlock,
null as BlockRemark,
null as AuthorizedName,
null as WhatsupNumber,
null as RequirePOBasedBilling,
null as RiskScore
from GMRSSep2025.dbo.tbconsumer   



--update a set LicenseeConsumerNum= RLICCONNUM

from t_party a, GMRS.dbo.tbconsumer b where a.pkid=b.CONNUM
----route id updateion queery----

----route id updateion queery----

SELECT TOP 10 *
-- UPDATE pa 
-- SET pa.route = ro.pkid
FROM GMRS_August2025.dbo.TBCONSUMER tbc
INNER JOIN t_Party pa 
    ON tbc.connum = pa.pkid
INNER JOIN t_route ro 
    ON (tbc.ZONNUM + tbc.BLKNUM + tbc.ROUNUM) COLLATE SQL_Latin1_General_CP1_CI_AS 
       = ro.bookno COLLATE SQL_Latin1_General_CP1_CI_AS;


/*--
UPDATEION STATEMENT  IN CONSUMER
--when LANDEDPROP 1 then acctype =LD
CASE 
WHEN LANDEDPROP = '1' AND ACCTYP IS NULL THEN (select am.PKID from t_AllMaster am inner join t_AllMasterType amt on am.MasterType=amt.PKID
           where amt.Name ='Control Account Type' and  am.code='LD')

*/

