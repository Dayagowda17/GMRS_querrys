
DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 0;
DECLARE @Districtid INT = 121;
DECLARE @Itemsegment BIT = 1;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL = 0.00;


DECLARE @APPSTA TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );
DECLARE @GASIN TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


    
DECLARE @INSBILIND TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @CTRTIND  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @PRVAPPSTA TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @CREBY TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [UserName] NVARCHAR(MAX)
    );



DECLARE @SITEIND TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

    

DECLARE @APRIND TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @APPBILIND TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @INIDEPIND TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );





DECLARE @MTRINSIND TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );




    INSERT INTO @APPSTA
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Application Status')
    


    INSERT INTO @GASIN
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Gas in Type')
---insert into t_application




    INSERT INTO @INSBILIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Installtion bill status Indicator')



    INSERT INTO @PRVAPPSTA
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Application Status')




INSERT INTO @CREBY 
SELECT PKID, UserName
FROM t_USER---where mastertype=(select PKID from t_allmastertype where Name='Application Status')





    INSERT INTO @CTRTIND 
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Contract Ind')


    INSERT INTO @SITEIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Site inspection status Indicator')




    INSERT INTO @APRIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Site approval status Indicator')





    INSERT INTO @APPBILIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Application bill status Indicator')




    INSERT INTO @INIDEPIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Init Deposit status Indicator')





    INSERT INTO @MTRINSIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='NAPS Meter installation status Indicator')

insert into t_APPLICATION
select 
 ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID,
  null  as 'ApplicantType',

connum as ConsumerNum,
NEWAPPDAT as ApplDate,


(SELECT [PKID] FROM @APPSTA WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(APPSTA)) AS 'Application Status', 
null as 'application group',


(SELECT [PKID] FROM @GASIN WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(GASIN)) AS 'Gas in Type', 

SITEDAT as SiteInspectionDate,
APRDAT as SiteApprovalDate,
APPBILDAT as ApplBillDate,
APPBILAMT as ApplBillAmount,
PAYAPPBILDAT as ApplBillPayDate,
INIDEPDAT as InitDepositDate,
null as InitDepositAmount,
PAYINIDEPDAT as InitDepositPayDate ,
INSBILDAT as InstBillDate,
INSTALAMT as InstBillAmount,
PAYINSBILDAT as InstBillPayDate,
(SELECT [PKID] FROM @GASIN WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(GASIN)) AS 'Installtion bill status Indicator', 

CTRNUM as ContractNum,
CTRTDAT as ContractDate,



(SELECT [PKID] FROM @CTRTIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(CTRTIND)) AS 'Contract Ind', 

INSTALAMT as MeterInstAmount,
MTRINSDAT as MeterInstDate ,


(SELECT [PKID] FROM @PRVAPPSTA WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(PRVAPPSTA)) AS 'Application Status', 
OLDREGNUM as OldRegisterNum,
ISSUERFLAG as IssuerFlag,

(SELECT [PKID] FROM @CREBY  WHERE [UserName] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(CREBY)) AS 'CreateBy', 
@ModifiedDate as modifieddate,
@modifiedby as ModifiedBy,
@Company_ID as 'company',
@ServiceLocation as 'service location',
@islegacyflag as LegacyFlag,

(SELECT [PKID] FROM @SITEIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(SITEIND)) AS 'Site inspection status Indicator', 

(SELECT [PKID] FROM @APRIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(APRIND)) AS 'Site approval status Indicator', 



(SELECT [PKID] FROM @APPBILIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(APPBILIND)) AS 'Application bill status Indicator', 




(SELECT [PKID] FROM @INIDEPIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(INIDEPIND)) AS 'Init Deposit status Indicator', 




(SELECT [PKID] FROM @MTRINSIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(APPBILIND)) AS 'NAPS Meter installation status Indicator', 


case 
when ISSUERFLAG=1 then (select am.PKID from t_AllMaster am inner join t_AllMasterType amt on am.MasterType=amt.PKID
                                                      where  amt.Name  like 'Application Source' and am.code ='0')
else (select am.PKID from t_AllMaster am inner join t_AllMasterType amt on am.MasterType=amt.PKID
                                                      where  amt.Name  like 'Application Source' and am.code ='1')

end  as 'ApplicationSource',
NULL as RequirednewMeter

from GMRS.dbo.TBNAPCONS 