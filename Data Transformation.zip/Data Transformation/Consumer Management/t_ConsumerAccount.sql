DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 0;
DECLARE @Districtid INT = 121;
DECLARE @Itemsegment BIT = 1;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL = 0.00;

DECLARE @LSTRDGTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );
    DECLARE @PRVCONSTA TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


INSERT INTO @LSTRDGTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Bill Reading Type')


INSERT INTO @PRVCONSTA
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='CONSUMER STATUS')


select TOP 10
  ROW_NUMBER() OVER (ORDER BY (SELECT NULL))AS PKID,
   CONNUM as ConsumerNum,
   SUPDAT as SupplyDate,
   SUPCMT as SupplyComment,
   LSTRDGDAT as LastReadingDate,
   LSTBILDAT as LastBillDate,
   DEPAMT as DepositAmt,
   null as AddlDepositAmt,
   AVGWBILAMT as AvgBillAmt,
   ARREARS as Arrears,
   SPECIALRATE as SpecialRate,
   PROVISIONRATE as ProvisionalRate,
(SELECT [PKID] FROM @LSTRDGTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(LSTRDGTYP)) AS 'Bill Reading Type', 

   
OLDACCNUM as OldAccountNum ,
DISCONDATE as DisconnectionDate,
ESTCNT as EstimatedCount,
ESTAMT as EstmatedAmount, 
null as ConsDisPercent,
LSTMONBILNUM as LastMonthBillNum,
LSTPAYNUM as LastPaymentNum,


(SELECT [PKID] FROM @PRVCONSTA  WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(PRVCONSTA)) AS 'PrevConsumerStatus', 

ILVIND as ILVIndicator,
BILCNT as BillCount,
CLOSEACCDAT as AccountCloseDate,
SPI as SPI,
INTCHARGE as InterestCharge,
CAPCONTR as CapitalContribution,
FIXCHARGE as FixedCharge,
DEPINTYR as DepInterestYear,
INSTALAMT as InstallationAmt,
INSPECAMT as InspectionAmt,
RECONAMT as ReconnectionAmt,
STAMPDAT as StampedDate,
ESTGSTCNT as EstimateGSTCount,
ESTGSTAMT as EstimateGSTAmt,
GSTREFIND as GSTReliefInd,
DISCREMARK as DisconRemark,
DISCREMARKDATE as DisconRemarkDate,
DATETOANM as DateToANM,
DLARREARS as DeliveryArrears,
SVCARREARS as ServiceArrears ,
SVCESTCNT as ServiceEstCount,
SVCESTAMT as ServiceEstAmount,
SVCESTTAXCNT as ServiceEstTaxCount,
SVCESTTAXAMT as ServiceEstTaxAmount,
MTHAVGBIL as MonthlyAvgBill,
null as ReportedNISFlag ,
null as ReportedNISDate,
@islegacyflag as LegacyFlag,
@CreatedBy AS CreateBy ,@ModifiedDate as' Modified date',
@ModifiedBy AS ModifiedBy ,
@Company_ID AS company ,
@ServiceLocation AS servicelocation,
 CONCAT(ZONNUM, BLKNUM, ROUNUM) AS 'bookno',
 NULL AS UnPostedArrears,
 NULL AS NonbillArrears


from GMRS_August2025.dbo. tbconsumer
