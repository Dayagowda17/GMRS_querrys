DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 0;
DECLARE @Districtid INT = 121;
DECLARE @Itemsegment BIT = 1;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL = 0.00;


INSERT INTO t_ConsumerPOSAddress

 
select  
    ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID,
     CONNUM AS ConsumerNum,
POSADDR1 as PostalAddress1,
POSADDR2 as PostalAddress2,
POSADDR3 as PostalAddress3,
POSCOD as PostalCode,
@islegacyflag as  LegacyFlag,
@CreatedBy  as CreateBy,
@ModifiedDate as modifieddate,
@ModifiedBy as ModifiedBy ,
@Company_ID  as company ,
@ServiceLocation as 'servicelocation' 
,@CreatedDate CreateDate
from GMRS.dbo.TBPOSADDR