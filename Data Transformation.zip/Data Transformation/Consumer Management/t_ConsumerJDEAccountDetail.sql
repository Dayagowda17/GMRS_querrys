DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 0;
DECLARE @Districtid INT = 121;
DECLARE @Itemsegment BIT = 1;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL = 0.00;

DECLARE @STORAGETYPE  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @LANDEDIND  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


INSERT INTO @STORAGETYPE
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Storage Type')



INSERT INTO @LANDEDIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Landed Prop Ind')
 
 ---insert into t_ConsumerJDEAccountDetail


select  
ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS PKID,
 CONNUM AS ConsumerNum,
JDECONNUM as JDEConsumerNum,
NAME as Name,
ADDRESS1 as Address1,
ADDRESS2 as Address2,
ADDRESS3 as Address3,
POSTCODE as PostCode, 





(SELECT [PKID] FROM @STORAGETYPE WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(STORAGETYPE)) AS 'Storage Type', 

LICNUM as LicenseNum ,
LICNAM as LIcenseName,
EFFDAT as EffectiveDate,
EXPDAT as ExpiryDate,
CNTRCTNUM as ContractNum,
@islegacyflag as LegacyFlag,
@CreatedBy as CreateBy ,
LSTUPD as ModifiedDate ,
@ModifiedBy as ModifiedBy,
@Company_ID as company ,
@ServiceLocation as servicelocation ,
UPDSTA  as UpdateStatus,
(SELECT [PKID] FROM @LANDEDIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(LANDEDIND)) AS 'LandedPropertyInd'


from GMRS.dbo. TBJDEUBISLIST
