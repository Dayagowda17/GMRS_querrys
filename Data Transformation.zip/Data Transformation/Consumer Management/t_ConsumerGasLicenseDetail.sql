DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 0;
DECLARE @Districtid INT = 121;
DECLARE @Itemsegment BIT = 1;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL = 0.00;

DECLARE @LICTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );
DECLARE @LICSTA TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

    DECLARE @STORTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

INSERT INTO @LICTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Supply by Account Type')

INSERT INTO @LICSTA
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='License Status')

INSERT INTO @STORTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Storage Type')


----------------------------- t_ConsumerGasLicenseDetail--------------------

insert into t_ConsumerGasLicenseDetail
select 
  ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID, 
   CONNUM AS ConsumerNum,
   LICNUM as LicenseNum,


(SELECT [PKID] FROM @LICTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(LICTYP)) AS 'License Type',




(SELECT [PKID] FROM @LICSTA WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(LICSTA)) AS 'License Status',




    EFFDAT as LicenseEffectiveDate,
    EXPDAT as LicenseExpiryDate,

    
(SELECT [PKID]  FROM @STORTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(STORTYP)) AS [Storage Type],



CDELIVERY as DeliveryContractFlag,
CSERVICE as ServiceContractFlag,
COPTSVC as OptionalServiceFlag,
JDECONNUM as JDEConsumerNum,
@islegacyflag as LegacyFlag,
@CreatedBy AS CreateBy,
LSTUPD as ModifiedDate,
@ModifiedBy AS ModifiedBy,
@Company_ID AS company ,
@ServiceLocation AS servicelocation,
@CreatedDate as'created date' ,
LICNAM as LicenceName
from  GMRS.dbo.TBGASLIC



SELECT * FROM T_ALLMASTERTYPE WHERE NAME LIKE 'L%'


select am.PKID from t_AllMaster am inner join t_AllMasterType amt on am.MasterType=amt.PKID
           where amt.Name ='License Type' and am.code='LP')