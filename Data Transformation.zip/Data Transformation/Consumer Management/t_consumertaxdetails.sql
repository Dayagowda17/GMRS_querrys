DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 0;
DECLARE @Districtid INT = 121;
DECLARE @Itemsegment BIT = 1;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL = 0.00;




 
select 
 ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID,
  CONNUM as ConsumerNum,
  null as GSTRegistrationName,
  CONGSTREGNO as GSTRegistrationNo,
  COMPNAM as CompanyName,
  null as Usage,
  BUSNAM as BusinessName,
  handphone as MobileNo,
  null as 'BusinessType',
  null as CompanyPhoneNo,
  null as OfficePhoneNo,
  @islegacyflag as LegacyFlag,
  @CreatedBy as CreateBy ,
  @ModifiedDate as 'modified date',
@ModifiedBy ModifiedBy,
@Company_ID as 'company' ,
@ServiceLocation as 'servicelocation' ,
@CreatedDate as  'created date'
from GRMSMAY2025.dbo.tbconsumer 