DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 0;
DECLARE @Districtid INT = 121;
DECLARE @Itemsegment BIT = 1;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL = 0.00;




-------t_party_area-------


insert into t_Party_Area
SELECT 
    ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID, 
    pKid AS partyid,
    @Itemsegment AS SegmentID,
    area AS AreaID,
    Route AS Routeid,
    NULL AS RouteJuntcionid,
    1 AS status,
   @CreatedBy AS createdby,
   @ModifiedBy AS lastmodifiedUserID,
    @CreatedDate AS createdate,
    @ModifiedDate AS LastModifiedDate,
    @Company_ID companyid,
    @ServiceLocation AS servicelocationid
FROM t_party;
