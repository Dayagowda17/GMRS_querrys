
--script of table t_TariffRevision dummy that why  t_TariffRevisionm create ward code---- 
CREATE TABLE t_TariffRevisiontemp (
    PKID              BIGINT NOT NULL, 
    TariffControl     BIGINT NULL,
    EffectiveDate     DATETIME NULL,
    RevisionNum       BIGINT NULL,
    MinimumCharge     DECIMAL(18,3) NULL,
    DiscountRate      DECIMAL(18,3) NULL,
    DepositCharge     DECIMAL(18,3) NULL,
    MeterRentalCharge DECIMAL(18,3) NULL,
    AvgConsumption    DECIMAL(18,3) NULL,
    GSTRate           DECIMAL(18,3) NULL,
    Multiplier        DECIMAL(18,3) NULL,
    CreatedBy         BIGINT NULL,
    CreateDate        DATETIME NULL,
    IsSuspended       BIT NULL,
    IsApproved        BIT NULL,
    IsActive          BIT NULL,
    ApprovedDate      DATETIME NULL,
    LastModifiedDate  DATETIME NULL,
    LastModifiedBy    BIGINT NULL,
    LegacyFlag        BIT NULL,
    ServiceLocation   BIGINT NULL,
    CompanyID         BIGINT NULL,
    WTARCOD           VARCHAR(10) NULL ,
    

STGQTY1 DECIMAL(18,3) NULL,
STGRAT1 DECIMAL(18,3) NULL, 
STGQTY2 DECIMAL(18,3) NULL, 
STGRAT2 DECIMAL(18,3) NULL
    -- Add data type as per your actual use
) ON [PRIMARY];

----------------------------------------------------------------





DECLARE @isActive BIT = 1;
DECLARE @isApproved BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @approvedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT=0;
--DECLARE @stateid INT = 5271;
DECLARE @Districtid INT = 121;
--DECLARE @TalukID INT = 328;
----DECLARE @CountryID INT = 149;
DECLARE @IsTariffFromRLic BIT = 0;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL=0.00;

INSERT INTO t_TariffRevisiontemp
SELECT * FROM (
    SELECT 
        ROW_NUMBER() OVER (ORDER BY EFFDAT, WTARCOD) AS pkid,  
        NULL AS tariffcontrol,
        EFFDAT,
        NULL AS rivisionnum,
        MINCHG,
        TARDISRAT,
        DEPCHARGE,
        MTRRNTL,
        AVGCONS,
        GSTTAXRATE,
        MULTIPLIER,
        @CreatedBy AS createdbby,
        @CreatedDate AS [created date],
        SUSPEND,
        @isApproved AS [is approved],
        @isActive AS [is active],
        @approvedDate AS [approved date],
        LSTUPD,
        @ModifiedBy AS modifiedby,
        @islegacyflag AS LegacyFlag,
        @ServiceLocation AS [service location],
        @Company_ID AS [company id],
        WTARCOD,  
       STGQTY1	,
       STGRAT1,
       STGQTY2,
       STGRAT2
    FROM GMRS_june2025.dbo.TBWTARIFF
) AS T;



--delete from t_TariffRevisiontemp

