DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT=0;
--DECLARE @stateid INT = 5271;
DECLARE @Districtid INT = 121;
--DECLARE @TalukID INT = 328;
----DECLARE @CountryID INT = 149;
DECLARE @IsTariffFromRLic BIT = 0;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL=0.00;



DECLARE @TARCOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );
    DECLARE @CONTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

      DECLARE @SUPPTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );
       DECLARE @TARTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );
    
    
    
INSERT INTO @TARCOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Tariff Code')

INSERT INTO @CONTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Consumer Type')

INSERT INTO @SUPPTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Supply Type')

INSERT INTO @TARTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Tariff Type')


--insert into t_TariffControl
select 
 ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS PKID,


(SELECT [PKID] FROM @TARCOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(TARCOD)) AS 'Tariff code',


(SELECT [PKID] FROM @CONTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(CONTYP)) AS 'CONSUMER TYPE',



(SELECT [PKID] FROM @SUPPTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(SUPPTYP)) AS 'CONSUMER TYPE',


(SELECT [PKID] FROM @TARTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(TARTYP)) AS 'TARIFF  TYPE',
@IsTariffFromRLic as 'IsTariffFromRLic',
@isActive as 'IsActive',
 @CreatedDate as 'CreateDate' ,
@ModifiedDate 'ModifiedDate',
@CreatedBy as CreateBy ,
@ModifiedBy as ModifiedBy ,
@islegacyflag as 'LegacyFlag',
@ServiceLocation as 'service location',
@Company_ID as 'company',
 null as 'RLICConsumerNo' ,
 null as LowBillWarnPercentage,
 null as HighBillWarnPercentage,
 null as SuspectBillConsLimit

from GMRS_AUGUST2025.dbo.tbtarctrl

