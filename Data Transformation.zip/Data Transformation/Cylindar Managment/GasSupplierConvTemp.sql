
create table GasSupplierConvTemp
(
    PKID INTEGER,
    supcod varchar(255),
    supconv decimal ,
    effdat DATETIME
)

--insert into GasSupplierConvTemp

select ROW_NUMBER() OVER (ORDER BY (SELECT NULL))  AS pkid ,
supcod as supcod,
supconv as supconv,
effdat as  effdat

 from   gmrs.dbo.TBGSUPCONV 
