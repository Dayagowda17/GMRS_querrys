
DECLARE @isActive BIT = 1;

DECLARE @GroupID INT = 8;
DECLARE @isApproved BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @approvedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT=0;
DECLARE @stateid INT = 5271;
DECLARE @Districtid INT = 121;
DECLARE @TalukID INT = 328;
DECLARE @CountryID INT = 149;
DECLARE @IsTariffFromRLic BIT = 0;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL=0.00;



 --INSERT INTO t_GasSupplierConv
select ROW_NUMBER() OVER (ORDER BY (SELECT NULL))  AS pkid ,
case 
when supcod='BHP' then 1
when supcod='NGC' then 2
when supcod='PTR' then 3
when supcod='SHELL' then 4
when supcod='PETRON' then 5
when supcod='BHP' then 6

end as Supplierid,
EFFDAT as EffectiveDate, SUPCONV as SupplierConv,
SUSPEND as IsSuspended, 
@CreatedDate  as CreateDate,
@isActive as IsActive ,
@CreatedBy as CreateBy, 
@ModifiedBy as ModifiedBy,
@ModifiedDate as ModifiedDate,
@ServiceLocation as ServiceLocation,
@Company_ID as CompanyID
 from   gmrs.dbo.TBGSUPCONV  J

