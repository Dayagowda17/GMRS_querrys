
DECLARE @isActive BIT = 1;

DECLARE @GroupID INT = 8;
DECLARE @isApproved BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @approvedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT=0;
DECLARE @stateid INT = 5271;
DECLARE @Districtid INT = 121;
DECLARE @TalukID INT = 328;
DECLARE @CountryID INT = 149;
DECLARE @IsTariffFromRLic BIT = 0;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL=0.00;

DECLARE @CYTYPE TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @WEIGHT TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

    
INSERT INTO @CYTYPE
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Cylinder Tariff Type')

INSERT INTO @WEIGHT
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Cylinder Unit Weight')

DECLARE @PSI TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

INSERT INTO @PSI
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Cylinder PSI')




--select * from EPBANK
--insert into t_CylTariffControl

select ROW_NUMBER() OVER (ORDER BY (SELECT NULL))  AS pkid,
CYLINDERCODE as TariffCode,
DESCR as TariffDesc,


(SELECT [PKID] FROM @CYTYPE WHERE [Name] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(CYTYPE)) AS 'Tariff Type', 


MTRIND as MeterInd ,
 CFFACTOR as CFFactor, 

(SELECT [PKID] FROM @WEIGHT WHERE [Name] COLLATE SQL_Latin1_General_CP1_CI_AS = WEIGHT) AS 'Unit Weight', 




(SELECT [PKID] FROM @PSI WHERE [Name] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(PSI)) AS 'PSI', 


@isActive as IsActive,
SUSPEND as IsSuspended, 
@CreatedDate as CreateDate, 
@ModifiedDate as ModifiedDate ,
@createdby as CreateBy, 
@ModifiedBy as ModifiedBy,
@islegacyflag as LegacyFlag , 
@ServiceLocation  as ServiceLocation,
@company_ID as CompanyID

  from  GMRS.dbo.TBCYLINDErtyp


