
DECLARE @isActive BIT = 1;

DECLARE @GroupID INT = 8;
DECLARE @isApproved BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @approvedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT=0;
DECLARE @stateid INT = 5271;
DECLARE @Districtid INT = 121;
DECLARE @TalukID INT = 328;
DECLARE @CountryID INT = 149;
DECLARE @IsTariffFromRLic BIT = 0;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL=0.00;



---------------------------------------------------t_CylTariffRevisionApproval---------------------------------------
insert into t_CylTariffRevisionApproval
select  ROW_NUMBER() OVER (ORDER BY (SELECT NULL))  AS pkid,
pkid as RevisionID,
null as Status, --form approval status
@CreatedDate as CreateDate,
null as Remark,
@CreatedBy  CreateBy ,
@ModifiedBy as ModifiedBy,
@ModifiedDate as ModifiedDate,
null from t_CylTariffRevision
where pkid not in (select RevisionID from t_CylTariffRevisionApproval)

--select * from t_allmastertype where name like 'fo%'

select * from t_allmaster where mastertype=529

--update t_CylTariffRevisionApproval set status=2912
