
DECLARE @isActive BIT = 1;

DECLARE @GroupID INT = 8;
DECLARE @isApproved BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @approvedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT=0;
DECLARE @stateid INT = 5271;
DECLARE @Districtid INT = 121;
DECLARE @TalukID INT = 328;
DECLARE @CountryID INT = 149;
DECLARE @IsTariffFromRLic BIT = 0;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL=0.00;


--insert into t_CylTariffRevision
select  ROW_NUMBER() OVER (ORDER BY (SELECT NULL))    AS pkid,
B.PKID as CylTariffControl, 
DATEFROMPARTS(YEAR(LSTUPD), MONTH(LSTUPD), 1) AS EffectiveDate,
1 as RevisionNum ,
PRICE as  UnitPrice,
 0 as GSTRate,
@CreatedBy as CreatedBy,
@CreatedDate as CreateDate,
SUSPEND as IsSuspended ,
@isApproved as IsApproved,
@isActive as IsActive,
LSTUPD as ApprovedDate ,
@ModifiedDate as LastModifiedDate ,
@ModifiedBy as LastModifiedBy,
@islegacyflag as LegacyFlag ,
@ServiceLocation as ServiceLocation,
@Company_ID as CompanyID
FROM GMRS.dbo.TBCYLINDERtyp A
JOIN t_CylTariffControl B 
  ON A.CYLINDERCODE COLLATE SQL_Latin1_General_CP1_CI_AS 
   = B.TARIFFCODE COLLATE SQL_Latin1_General_CP1_CI_AS