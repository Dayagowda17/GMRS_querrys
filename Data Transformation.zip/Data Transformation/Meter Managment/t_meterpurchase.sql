


---update the meter status as per client requirement in source database


case 1:

SELECT *

--update a set masmtrstat=0
FROM tbmasmeter a
WHERE MTRNUM NOT IN (
    SELECT MTRNUM
    FROM TBMETER
)


case 2:

SELECT top 100 a.MTRNUM,b.CONNUM,b.mtrnum,d.DESCR AS 'METER STATUS',C.DESCR AS 'installedMeterStatus'
--count(*)

--update a set masmtrstat=1  ---INSTALLED METER
FROM tbmasmeter a
JOIN tbmeter b ON a.mtrnum = b.MTRNUM
JOIN tbmtrstatus c ON b.MTRSTAT = c.MTRSTAT
JOIN TBMASSTATUS d ON a.MASMTRSTAT = d.MASMTRSTAT
WHERE d.DESCR = 'FREE METER'
  AND c.DESCR = 'ACTIVE';



CASE 3:

SELECT top 100 a.MTRNUM,b.CONNUM,b.mtrnum,d.DESCR AS 'METER STATUS',C.DESCR AS 'installedMeterStatus'
--count(*)

--update a set masmtrstat=2  -----DISCONNECTED METER
FROM tbmasmeter a
JOIN tbmeter b ON a.mtrnum = b.MTRNUM
JOIN tbmtrstatus c ON b.MTRSTAT = c.MTRSTAT
JOIN TBMASSTATUS d ON a.MASMTRSTAT = d.MASMTRSTAT
WHERE d.DESCR = 'FREE METER'
  AND c.DESCR = 'DISCONNECTED';



CASE 4:


SELECT top 100 a.MTRNUM,b.CONNUM,b.mtrnum,d.DESCR AS 'METER STATUS',C.DESCR AS 'installedMeterStatus'
--count(*)

--update a set masmtrstat=2  -----DISCONNECTED METER

FROM tbmasmeter a
JOIN tbmeter b ON a.mtrnum = b.MTRNUM
JOIN tbmtrstatus c ON b.MTRSTAT = c.MTRSTAT
JOIN TBMASSTATUS d ON a.MASMTRSTAT = d.MASMTRSTAT
WHERE d.DESCR = 'FREE METER'
  AND c.DESCR = 'REPLACED';



CASE 5:


SELECT top 100 a.MTRNUM,b.CONNUM,b.mtrnum,d.DESCR AS 'METER STATUS',C.DESCR AS 'installedMeterStatus'
--count(*)

--update a set masmtrstat=2  ---DISCONNECTED METER
FROM tbmasmeter a
JOIN tbmeter b ON a.mtrnum = b.MTRNUM
JOIN tbmtrstatus c ON b.MTRSTAT = c.MTRSTAT
JOIN TBMASSTATUS d ON a.MASMTRSTAT = d.MASMTRSTAT
WHERE d.DESCR = 'INSTALLED METER'
  AND c.DESCR = 'DISCONNECTED';


CASE 6:


SELECT top 100 a.MTRNUM,b.CONNUM,b.mtrnum,d.DESCR AS 'METER STATUS',C.DESCR AS 'installedMeterStatus'
--count(*)

--update a set masmtrstat=2  ---DISCONNECTED METER
FROM tbmasmeter a
JOIN tbmeter b ON a.mtrnum = b.MTRNUM
JOIN tbmtrstatus c ON b.MTRSTAT = c.MTRSTAT
JOIN TBMASSTATUS d ON a.MASMTRSTAT = d.MASMTRSTAT
WHERE d.DESCR = 'INSTALLED METER'
  AND c.DESCR = 'REPLACED';

--------------------------------------------------------



case 7 :





SELECT top 100 a.MTRNUM,b.CONNUM,b.mtrnum,d.DESCR AS 'METER STATUS',C.DESCR AS 'installedMeterStatus'
--count(*)

--update a set masmtrstat=1  ---INSTALLED METER
FROM tbmasmeter a
JOIN tbmeter b ON a.mtrnum = b.MTRNUM
JOIN tbmtrstatus c ON b.MTRSTAT = c.MTRSTAT
JOIN TBMASSTATUS d ON a.MASMTRSTAT = d.MASMTRSTAT
WHERE d.DESCR = 'FAULTY METER'
  AND c.DESCR = 'ACTIVE';


------------------------------------------------------------------------------------------
Meter Purchase Query


DECLARE @NextPKID INT;
DECLARE @isActive BIT=1;
DECLARE @ApprovedBy INT=90;
DECLARE @Company_ID INT=98;
DECLARE @CreatedDate DATETIME=GETDATE();
DECLARE @CreatedBy INT=90;
DECLARE @ModifiedBy INT=90;
DECLARE @ModifiedDate DATETIME=GETDATE();
DECLARE @ServiceLocation INT=10268;


DECLARE @isSingleEntry BIT=1;

insert into T_METERPURCHASE
SELECT
    ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS NextPKID,  
    PURCDAT AS PURCHASEDATE,
    PURCDOC AS PurchaseDoc,
    MFGDAT AS ManufactureDate,
    NULL AS MeterNumPrefix,  
    NULL AS MeterNumFrom,    
    NULL AS MeterNumTo,      
    NULL AS MeterNumSuffix,  
    1AS MeterBatchTotalNewQty,           
    0AS MeterBatchTotalFailQty,          
    1AS LegacyFlag,                      
     @CreatedDate as CreatedDate,              
    @CreatedBy AS CreateBy,                       
    @ModifiedBy AS ModifiedBy,                     
    @ModifiedDate  AS ModifiedDate,            
    @ServiceLocation AS ServiceLocation,             
    @Company_ID AS CompanyID,                      
    NULL AS MeterSerialNum,
    @isSingleEntry as  isSingleEntry
from GMRS.dbo.tbmasmeter

