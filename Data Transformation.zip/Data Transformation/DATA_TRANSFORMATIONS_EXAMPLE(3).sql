USE GMRSAugust2025

GO

/*DECLARE REGION TEMP TABLES */
DECLARE @Region TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @Zone TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @Block TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @Branch TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );



/*LOAD REGION TEMP TABLES*/

PRINT '**INSERTING ZONE RECORDS INTO TEMP TABLE**'

INSERT INTO @Zone
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Zone')

PRINT '**INSERTING BLOCK RECORDS INTO TEMP TABLE**'

INSERT INTO @Block
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Block')

PRINT '**INSERTING BRANCH RECORDS INTO TEMP TABLE**'

INSERT INTO @Branch
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Branch Code')

PRINT '**INSERTING REGION RECORDS INTO TEMP TABLE**'

INSERT INTO @Region
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Region Code')

/*END LOADING*/

PRINT '**GENERATING TRANSFORMED RECORDS FOR T_REP_AREA TABLE**'

/*FINAL TRANSFORM QUERY*/
select 
(SELECT [PKID] FROM @Zone WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(Z.ZONNUM)) AS 'ZONE', 
(SELECT [PKID] FROM @Block WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(Z.BLKNUM)) AS 'BLOCK', 
(SELECT [PKID] FROM @Branch WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(Z.BRANCHCOD)) AS 'BRANCH',
TRIM(DESCR) AS 'AREANAME', 
(SELECT [PKID] FROM @Region WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(Z.REGIONCOD)) AS 'REGION'
from GMRS_August2025.dbo.tbzone Z

GO
