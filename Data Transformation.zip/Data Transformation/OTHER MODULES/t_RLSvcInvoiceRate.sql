
DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;


--insert into t_RLSvcInvoiceRate
select 

 ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS PKID,
 connum as RLConnum,
 null as RateSeqNum,
 null as EffectiveDate,
 STGQTY1 AS Slab1Qty,
STGRAT1 AS Slab1Rate,
 STGQTY2 AS Slab2Qty,
STGRAT2 AS Slab2Rate,
 STGQTY3 AS Slab3Qty,
STGRAT3 AS Slab3Rate,
@isActive AS  Legacyflag,
 @ModifiedDate as LastUpdateDate,
 @CreatedBy as LastUpdateUserId
 from gmrssep2025.dbo.TBRLINVRATE

 --select top 10 *  from gmrssep2025.dbo.TBRLINVRATE
 select * from t_RLSvcInvoiceRate