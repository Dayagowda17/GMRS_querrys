DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 0;
DECLARE @Districtid INT = 121;
DECLARE @Itemsegment BIT = 1;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL = 0.00;





/*DECLARE REGION TEMP TABLES */
DECLARE @ADJREACOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @FIFOIND TABLE (
           [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @DEPSTA  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @CONTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @WTARCOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


/*LOAD REGION TEMP TABLES*/

PRINT '**INSERTING ZONE RECORDS INTO TEMP TABLE**'

INSERT INTO @ADJREACOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Adjustment Reason')

PRINT '**INSERTING ZONE RECORDS INTO TEMP TABLE**'

INSERT INTO @FIFOIND
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Open Item Status')

PRINT '**INSERTING ZONE RECORDS INTO TEMP TABLE**'

INSERT INTO @DEPSTA
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Deposit Status')

PRINT '**INSERTING BLOCK RECORDS INTO TEMP TABLE**'

INSERT INTO @CONTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Consumer Type')

PRINT '**INSERTING BRANCH RECORDS INTO TEMP TABLE**'


INSERT INTO @WTARCOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Tariff Code')



--------------------------------t_DepositBatch-------------------

/**

INSERT INTO t_ConsumerDepositStatement
(
    pkid,
    DepBatchNum,
    ConsumerNum,
    TariffCode,
    ConsumerName,
    ConsumerType,
    OldAccountNum,
    AddDepositAmount,
    IssueDate,
    ReceiptNum,
    ReceiptDate,
    DepStatus,
    AdjReasonCode,
    DepPaidAmount,
    ModifiedDate,
    ModifiedBy,
    FIFOOSBalance,
    FIFOIndicator,
    AvgDepAmount,
    DepAmount,
    LastBillDate,
    CreateBy,
    CreateDate,
    CompanyID,
    ServiceLocation,
    IsActive
) **/
insert into t_ConsumerDepositStatement
SELECT 
        DEPNUM   AS pkid,
 A.CONNUM as ConsumerNum,

 (SELECT [PKID] FROM @WTARCOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(A.WTARCOD)) AS 'TARIFF CODE', 

A.CONNAM as ConsumerName,
(SELECT [PKID] FROM @CONTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(B.CONTYP)) AS 'ConsumerType',

case 
when A.OLDACCNUM is not null then A.OLDACCNUM 
else '' end as 'OldAccountNum',
A.ADDDEPAMT as AddDepositAmount,
ISSUEDAT as IssueDate,
RCPNUM as ReceiptNum,
CAST(ISNULL(RCPDAT, '1900-01-01') AS datetime) as ReceiptDate,
(SELECT [PKID] FROM @DEPSTA WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(DEPSTA)) AS  'DepStatus',
(SELECT [PKID] FROM @ADJREACOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(ADJREACOD)) AS 'AdjReasonCode',
 DEPPAIDAMT as DepPaidAmount,
 @ModifiedDate as 'ModifiedDate',
 @modifiedby as ModifiedBy ,
 FIFOOSBALAMT as FIFOOSBalance,
(SELECT [PKID] FROM @FIFOIND WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(FIFOIND)) AS 'FIFOIndicator',
AVGDEPAMT as AvgDepAmount,
A.DEPAMT as DepAmount,
A.LSTBILDAT as LastBillDate,  
  RLPAYIND as RLPAYIND, 
@createdby as CreateBy,
@CreatedDate as CreateDate,
@company_ID  as CompanyID,
@ServiceLocation as ServiceLocation,
@isActive as IsActive,
 DEPBATCHNUM  as 'DepBatchNum '  
  from  GMRSSep2025.dbo.TBDEPSTMT  A, GMRSSep2025.dbo.TBCONSUMER B WHERE A.CONNUM=B.CONNUM 
