create dummy table  same structures 

/*CREATE temp table for getting consumer type and use this table to update
the destination table*/
SELECT DEPBATCHNUM,CONTYP FROM
(SELECT A.DEPBATCHNUM, (SELECT TOP 1 CONNUM FROM TBDEPSTMT B WHERE B.DEPBATCHNUM=A.DEPBATCHNUM) AS CONNUM FROM TBDEPBATCH A ) D
INNER JOIN TBCONSUMER E ON E.CONNUM=D.CONNUM

/*BATCH RECORDS FOR WHICH THERE IS NO RECORD IN THE DEPOSIT STATEMENT TABLE -FOR THESE CONSUMER TYPE CANNOT BE DETERMINED*/
/*There are 86 such batches . We decide this after discussing with Vinayak*/

SELECT * from TBDEPBATCH a WHERE NOT EXISTS (SELECT * FROM TBDEPSTMT WHERE DEPBATCHNUM=A.DEPBATCHNUM) 



-----------------



select  
row_number() over(order by(select null)) as pkid,
CONNUM as ConsumerNum,
case
when ADJREACOD='86' then 563 when ADJREACOD='90' then 567 when ADJREACOD='91' then 568end as 'AdjReasonCode', 

CASE 
        WHEN BANKCOD = 22 THEN 22
        WHEN BANKCOD = 27 THEN 27
        WHEN BANKCOD = 32 THEN 32
        WHEN BANKCOD = 37 THEN 37
        WHEN BANKCOD = 42 THEN 42
       
    END  as 'BankCode',EFFDAT as EffectiveDate,EXPIRYDAT as ExpiryDate , BGAMT as BGAmount, DEPNUM  as ' DepositNum ',
case
when BGSTA='1' then 741 when BGSTA='4' then 742end as 'BGStatus',
 case when PRVBGSTA='1' then 2011end as 'BGPrevStatus',  case when CANREACOD ='02' then 774end as 'BGCancelReasonCode',CANCELDAT as BGCancelDate,
case
 when CANCELBY='AIDA' then 24 else  null end   as BGCanceByUser,
 CLAIMRMK as BGClaimRemark,CLAIMDAT as BGClaimDate,BGCLAIMAMT as BGClaimAmount,CLAIMBY as BGClaimByUser,CLAIMCOMPDAT as BGClaimCompDate,CLAIMCOMPBY as BGClaimCompByUser,RELEASEDAT as BGReleaseDate,RELEASEBY as BGReleaseByUser,RMDISSDAT as BGRMDissDate,RMDISSBY as BGRMDissBy,CLOSERMK as BGCloseRemark,CLOSEDAT as BGCloseDate,CLOSEBY as  BGCloseBy,
GETDATE() as CreatedDate ,
case
when CREATEBY='AIDA' then 24 when CREATEBY='LIDYA' then 105 when CREATEBY='SHAM' then 158 when CREATEBY='SUZI' then 172 end 
 as 'CreatedBy' ,LSTUPD as LastUpdateDate,90 as LastUpdateBy,1 as IsActive
 from  MalaysiaNewBackup.dbo. TBBANKGUARANTEE 


