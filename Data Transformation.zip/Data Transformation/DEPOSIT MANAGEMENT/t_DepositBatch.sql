
DECLARE @isActive BIT = 1;

DECLARE @GroupID INT = 8;
DECLARE @isApproved BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @approvedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT=0;
DECLARE @stateid INT = 5271;
DECLARE @Districtid INT = 121;
DECLARE @TalukID INT = 328;
DECLARE @CountryID INT = 149;
DECLARE @IsTariffFromRLic BIT = 0;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL=0.00;



DECLARE @DEPBATCHSTA TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @CREBY TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [UserName] NVARCHAR(MAX)
    );


INSERT INTO @DEPBATCHSTA
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Deposit batch status')


INSERT INTO @CREBY
select PKID,UserName from t_User

--------------------------------t_DepositBatch-------------------
INSERT INTO t_DepositBatch


  select   DEPBATCHNUM AS pkid,

(SELECT [PKID] FROM @CREBY WHERE [UserName] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(CREBY)) AS 'CreatedBy', 

(SELECT [PKID] FROM @CREBY WHERE [UserName] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(RECBY)) AS 'ReceivedBy ',
DEPBATDAT as DepBatchDate,   
DEPDUEDAT as DepBatchDueDate,
TOTDEPADV as  TotalDepStmtCount ,
TOTDEPPAID as TotalDepPaidCount ,
 null as DepCriteria ,
 0 as NumOfAvgPeriods,
 0 as NoOfHighBills,
 
(SELECT [PKID] FROM @DEPBATCHSTA WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(DEPBATCHSTA)) AS ' DEPBATCHSTA', /*UPDATE THE DEPBATCH STTAUS ->N AS CLOSED */
   @isApproved as IsProcessed,
   @isActive as IsActive,
  @ModifiedDate as LastUpdateDate,
@ModifiedBy as LastUpdateBy,
@islegacyflag as LegacyFlag,
null as ConsumerType,
null as TotalAddlDepAmount

  from GMRSSep2025.dbo. TBDEPBATCH 