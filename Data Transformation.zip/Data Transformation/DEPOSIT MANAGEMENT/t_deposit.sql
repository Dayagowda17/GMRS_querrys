DECLARE @isActive BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT = 0;
DECLARE @Districtid INT = 121;
DECLARE @Itemsegment BIT = 1;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL = 0.00;

DECLARE @ADJREACOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @DEPTYP TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

    
INSERT INTO @ADJREACOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Adjustment Reason')



INSERT INTO @DEPTYP
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Deposit Type')

---------------------t_deposit--------------------------------
---insert into t_Deposit

SELECT 
    ROW_NUMBER() OVER (ORDER BY (SELECT NULL))  AS pkid,
    CONNUM AS ConsumerNum,
    DEPDAT AS DepositDate,

(SELECT [PKID] FROM @DEPTYP WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(DEPTYP)) AS 'DepositType', 



    TRY_CAST(DEPAMT AS DECIMAL(18, 2)) AS DepositAmount,
    try_cast(RCPNUM as float) AS ReceiptNum,
    RCPDAT AS ReceiptDate,
    TRY_CAST(DEPBKIDX AS INT) AS DepBKIndex,
    APPNUM AS ApplicationNum,
    POSDAT AS DepPostDate,
      
(SELECT [PKID] FROM @ADJREACOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(ADJREACOD)) AS 'AdjReasonCode',
    RFDVOUNUM AS RFDVoucherNo,
    PRINTED AS Printed,
    try_cast(LSTUPD as int) AS LastUpdateDate,
    @ModifiedBy AS LastUpdateBy,
    TRY_CAST(PAYNUM AS INT) AS PaymentNum,
    @isActive AS IsActive,
    @islegacyflag AS LegacyFlag
FROM GMRS_june2025.dbo.TBDEPOSIT ;


