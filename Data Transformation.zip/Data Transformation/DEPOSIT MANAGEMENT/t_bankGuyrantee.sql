
DECLARE @isActive BIT = 1;

DECLARE @GroupID INT = 8;
DECLARE @isApproved BIT = 1;
DECLARE @ApprovedBy INT = 90;
DECLARE @Company_ID INT = 98;
DECLARE @ModifiedBy INT = 90;
DECLARE @CreatedDate DATETIME = GETDATE();
DECLARE @ModifiedDate DATETIME = GETDATE();
DECLARE @CreatedBy INT = 90;
DECLARE @approvedDate DATETIME = GETDATE();
DECLARE @ServiceLocation INT = 10268;
DECLARE @isDefault BIT=0;
DECLARE @stateid INT = 5271;
DECLARE @Districtid INT = 121;
DECLARE @TalukID INT = 328;
DECLARE @CountryID INT = 149;
DECLARE @IsTariffFromRLic BIT = 0;
DECLARE @islegacyflag BIT = 1;
DECLARE @GSTRateIndicator BIT = 0;
DECLARE @GSTPercentage DECIMAL=0.00;


--select * from EPBANK


--select * from EPBANK
---insert into t_BankGuarantee
/**INSERT INTO t_BankGuarantee
(
    pkid,
    ConsumerNum,
    AdjReasonCode,
    BankCode,
    EffectiveDate,
    ExpiryDate,
    BGAmount,
    DepositNum,
    BGStatus,
    BGCancelReasonCode,
    BGCancelDate,
    BGCanceByUser,
    BGClaimRemark,
    BGClaimDate,
    BGClaimAmount,
    BGClaimByUser,
    BGClaimCompDate,
    BGClaimCompByUser,
    BGReleaseDate,
    BGReleaseByUser,
    BGRMDissDate,
    BGRMDissBy,
    BGCloseRemark,
    BGCloseDate,
    BGCloseBy,
    CreatedDate,
    CreatedBy,
    LastUpdateDate,
    LastUpdateBy,
    IsActive
)*/





DECLARE @ADJREACOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @BANKCOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Name] NVARCHAR(MAX)
    );

DECLARE @BGSTA  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @PRVBGSTA  TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

DECLARE @CANREACOD TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


DECLARE @CANCELBY TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [UserName] NVARCHAR(MAX)
    );

DECLARE @Region TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );


/*LOAD REGION TEMP TABLES*/

PRINT '**INSERTING ZONE RECORDS INTO TEMP TABLE**'

INSERT INTO @ADJREACOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Adjustment Reason')

PRINT '**INSERTING ZONE RECORDS INTO TEMP TABLE**'

INSERT INTO @BANKCOD
select PKID,Name from t_BANK

PRINT '**INSERTING ZONE RECORDS INTO TEMP TABLE**'

INSERT INTO @BGSTA 
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Bank Guarantee Status')


INSERT INTO @PRVBGSTA
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Bank Guarantee Status')


PRINT '**INSERTING BLOCK RECORDS INTO TEMP TABLE**'

INSERT INTO @CANREACOD
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Bank Guarantee Cancel Reason Code')

PRINT '**INSERTING BRANCH RECORDS INTO TEMP TABLE**'

INSERT INTO @CANCELBY
select PKID,UserName from t_User
PRINT '**INSERTING REGION RECORDS INTO TEMP TABLE**'
insert into t_BankGuarantee
select  top 10
row_number() over(order by(select null)) as pkid,
CONNUM as ConsumerNum,


(SELECT [PKID] FROM @ADJREACOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(ADJREACOD)) AS 'AdjReasonCode', 


(SELECT [PKID] FROM @BANKCOD WHERE [PKID] = BANKCOD) AS 'BankCode', 

    EFFDAT as EffectiveDate,
    EXPIRYDAT as ExpiryDate , 
    BGAMT as BGAmount, 
   
(SELECT [PKID] FROM @BGSTA WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(BGSTA)) AS 'BGStatus', 


(SELECT [PKID] FROM @PRVBGSTA WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(PRVBGSTA)) AS 'Previous BGStatus', 


 -- doubt --case when PRVBGSTA='1' then 2011 else null end as 'BGPrevStatus',


 
(SELECT [PKID] FROM @CANREACOD WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(CANREACOD)) AS 'BGCancelReasonCode', 

   CANCELDAT as BGCancelDate,




(SELECT [PKID] FROM @CANCELBY WHERE [UserName] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(CANCELBY)) AS 'BGCanceByUser', 


 CLAIMRMK as BGClaimRemark,
 CLAIMDAT as BGClaimDate,
 BGCLAIMAMT as BGClaimAmount,
 CLAIMBY as BGClaimByUser,
 CLAIMCOMPDAT as BGClaimCompDate,
 CLAIMCOMPBY as BGClaimCompByUser,
 RELEASEDAT as BGReleaseDate,
 RELEASEBY as BGReleaseByUser,
 RMDISSDAT as BGRMDissDate,
 RMDISSBY as BGRMDissBy,
 CLOSERMK as BGCloseRemark,
 CLOSEDAT as BGCloseDate,
 CLOSEBY as  BGCloseBy,
@CreatedDate as CreatedDate ,
(SELECT [PKID] FROM @CANCELBY WHERE [UserName] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(CREATEBY)) AS 'CreatedBy', 
 LSTUPD as LastUpdateDate,
@ModifiedBy as LastUpdateBy,
@isActive as IsActive,
DEPNUM as DepositNum
 from  GMRS.dbo.TBBANKGUARANTEE 


 --select top 10 * from  GMRS_August2025.dbo. TBBANKGUARANTEE 

