DECLARE @LEGACYFLAG BIT=1;
DECLARE @DISCBATSTA TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

INSERT INTO @DISCBATSTA 
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Disconnection Batch status')



DECLARE @DISCTYPE TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

INSERT INTO @DISCTYPE
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='Disconnection Type')


DECLARE @TOCOMPELETEBY TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [Code] NVARCHAR(MAX),
        [Name] NVARCHAR(MAX)
    );

INSERT INTO @TOCOMPELETEBY
select PKID,Code,Name from t_allmaster where mastertype=(select PKID from t_allmastertype where Name='To Complete by')




DECLARE @USRID TABLE (
        [PKID] INTEGER PRIMARY KEY,
        [UserName] NVARCHAR(MAX)
    );



INSERT INTO @USRID
select PKID,UserName from t_User
insert into t_DisconnectionBatch
SELECT  
BATCHNUM AS PKID,
(SELECT [PKID] FROM @USRID WHERE [UserName] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(BATCREBY)) AS 'CREATEDBY',

(SELECT [PKID] FROM @USRID WHERE [UserName] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(BATRECBY)) AS 'RECEIVEDBY',
DISCBATDAT  AS DisconBatchDate,
DISCDUEDAT AS DisconBatchDueDate,
(SELECT [PKID] FROM @DISCBATSTA WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(DISCBATSTA)) AS 'Disconnection Batch status', 


(SELECT [PKID] FROM @DISCTYPE WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(DISCTYPE)) AS 'Disconnection Type', 
TOTDISCWO AS DisconWOCount,
TOTDISCARR AS TotalArrears,
CREATEDDATE AS CreateDate,
(SELECT [PKID] FROM @TOCOMPELETEBY WHERE [Code] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(TOCOMPLETEBY)) AS 'TOCOMPLETEBY', 
LSTUPDDATE AS LastUpdateDate,
(SELECT [PKID] FROM @USRID WHERE [UserName] COLLATE SQL_Latin1_General_CP1_CI_AS = TRIM(LSTUPDBY)) AS 'LastUpdateUserID',

@LEGACYFLAG AS LEAGACYFLAG


 FROM GMRS.DBO.TBDISCBATCH




