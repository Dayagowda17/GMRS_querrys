select distinct WOPERBY from tbworder where issuerflag=1

select top 10 * from tbworder



select distinct WOCREBY from tbworder a  where issuerflag is null and not exists (select * from tbuser b where b.usrid=a.WOCREBY)




select distinct WOPERBY from tbworder a  where issuerflag is null and not exists (select * from tbuser b where b.usrid=a.WOperBY)




select max(wodat) from tbworder where  WOCREBY  like 'AJAY%'


select distinct WOCREBY from tbworder a  where issuerflag is null and not exists (select * from tbuser b where b.usrid=a.WOCREBY)  ----INCATIVE=1


select * from tbuser where usrid like '%API%'




select distinct WOCREBY from tbworder  where issuerflag =1


SELECT COUNT(*) FROM TBOPITEMS WHERE EVNTYP='3' AND EVNGRP='80'


SELECT COUNT(*) FROM TBBILL WHERE EVNTYP='3' AND EVNGRP='80'


SELECT COUNT(*) FROM TBOPITEMS WHERE EVNTYP='0' AND EVNGRP='80'

SELECT TOP 10 * FROM TBOPITEMS WHERE EVNTYP='0' AND EVNGRP='80' ORDER BY APPDAT DESC



SELECT * FROM TBBILL WHERE CONNUM=110142 AND BILREFNUM=7649470

SELECT * FROM TBBILL WHERE BILNUM IN(7649471,7649470)


SELECT * FROM TBOPITEMS WHERE BILNUM IN(7649471,7649470)



SELECT MAX(APPDAT) FROM TBOPITEMS WHERE EVNTYP='0' AND EVNGRP='80'


---  CASE  1 0 1 2 & 4 Should INSERT THE DATA INTO T_BILLTAX TABLE   evntyp in(0,1,2,4) and evngrp=80

--case other than evntyp=3 and evngrp=80 insert the data into t_bil
SELECT TOP 10 * FROM TBBILL A WHERE EVNTYP!='3' AND EVNGRP='80'AND EXISTS (SELECT * FROM TBOPITEMS B WHERE A.BILNUM=B.BILNUM) ---  CASE  1 0 1 2 & 4 SHOULB INSERT THE DATA INTO T_BILLTAX TABLE  




SELECT TOP 10 * FROM TBBILL A WHERE EVNTYP='0' AND EVNGRP='80'






select distinct WOCREBY from tbworder a  where issuerflag is null and not exists (select * from tbuser b where b.usrid=a.WOCREBY)


select --top 10 a.bilnum,b.bilnum,bildat
count(*)

from tbbill a ,TBBILITMHIST b where a.bilnum=b.bilnum order by bildat DESC

select count(*) from TBMETER



SELECT top 100 a.MTRNUM,b.CONNUM,b.mtrnum,d.DESCR 
--count(*)
FROM tbmasmeter a
JOIN tbmeter b ON a.mtrnum = b.MTRNUM
JOIN tbmtrstatus c ON b.MTRSTAT = c.MTRSTAT
JOIN TBMASSTATUS d ON a.MASMTRSTAT = d.MASMTRSTAT
WHERE d.DESCR = 'free METER'
  AND c.DESCR = 'disconnected';

  select *  from TBMASSTATUS 