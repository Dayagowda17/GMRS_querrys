----METER MANAGEMENT----



SELECT COUNT(*) FROM T_METERDETAILS
SELECT COUNT(*) FROM T_METERPURCHASE

select count(*) from TBMASMETER
select count(*) from TBMETER


SELECT count(*)

--update a set masmtrstat=0
FROM tbmasmeter a
WHERE MTRNUM NOT IN (
    SELECT MTRNUM
    FROM TBMETER
)


---case 1:

SELECT *

--update a set masmtrstat=0
FROM tbmasmeter a
WHERE MTRNUM NOT IN (
    SELECT MTRNUM
    FROM TBMETER
)


---case 2:

SELECT ---top 100 a.MTRNUM,b.CONNUM,b.mtrnum,d.DESCR AS 'METER STATUS',C.DESCR AS 'installedMeterStatus'
COUNT(*)

--update a set masmtrstat=1  ---INSTALLED METER
FROM tbmasmeter a
JOIN tbmeter b ON a.mtrnum = b.MTRNUM
JOIN tbmtrstatus c ON b.MTRSTAT = c.MTRSTAT
JOIN TBMASSTATUS d ON a.MASMTRSTAT = d.MASMTRSTAT
WHERE d.DESCR = 'FREE METER'
  AND c.DESCR = 'ACTIVE';



---case 3:

SELECT ---top 100 a.MTRNUM,b.CONNUM,b.mtrnum,d.DESCR AS 'METER STATUS',C.DESCR AS 'installedMeterStatus'
COUNT(*)

--update a set masmtrstat=2  -----DISCONNECTED METER
FROM tbmasmeter a
JOIN tbmeter b ON a.mtrnum = b.MTRNUM
JOIN tbmtrstatus c ON b.MTRSTAT = c.MTRSTAT
JOIN TBMASSTATUS d ON a.MASMTRSTAT = d.MASMTRSTAT
WHERE d.DESCR = 'FREE METER'
  AND c.DESCR = 'DISCONNECTED';



---case 4:


SELECT ---top 100 a.MTRNUM,b.CONNUM,b.mtrnum,d.DESCR AS 'METER STATUS',C.DESCR AS 'installedMeterStatus'
COUNT(*)

--update a set masmtrstat=2  -----DISCONNECTED METER

FROM tbmasmeter a
JOIN tbmeter b ON a.mtrnum = b.MTRNUM
JOIN tbmtrstatus c ON b.MTRSTAT = c.MTRSTAT
JOIN TBMASSTATUS d ON a.MASMTRSTAT = d.MASMTRSTAT
WHERE d.DESCR = 'FREE METER'
  AND c.DESCR = 'REPLACED';



---case 5:


SELECT ---top 100 a.MTRNUM,b.CONNUM,b.mtrnum,d.DESCR AS 'METER STATUS',C.DESCR AS 'installedMeterStatus'
COUNT(*)

--update a set masmtrstat=2  ---DISCONNECTED METER
FROM tbmasmeter a
JOIN tbmeter b ON a.mtrnum = b.MTRNUM
JOIN tbmtrstatus c ON b.MTRSTAT = c.MTRSTAT
JOIN TBMASSTATUS d ON a.MASMTRSTAT = d.MASMTRSTAT
WHERE d.DESCR = 'INSTALLED METER'
  AND c.DESCR = 'DISCONNECTED';


---case 6:


SELECT ---top 100 a.MTRNUM,b.CONNUM,b.mtrnum,d.DESCR AS 'METER STATUS',C.DESCR AS 'installedMeterStatus'
COUNT(*)

--update a set masmtrstat=2  ---DISCONNECTED METER
FROM tbmasmeter a
JOIN tbmeter b ON a.mtrnum = b.MTRNUM
JOIN tbmtrstatus c ON b.MTRSTAT = c.MTRSTAT
JOIN TBMASSTATUS d ON a.MASMTRSTAT = d.MASMTRSTAT
WHERE d.DESCR = 'INSTALLED METER'
  AND c.DESCR = 'REPLACED';

--------------------------------------------------------



---case 7 :





SELECT ---top 100 a.MTRNUM,b.CONNUM,b.mtrnum,d.DESCR AS 'METER STATUS',C.DESCR AS 'installedMeterStatus'
COUNT(*)

--update a set masmtrstat=1  ---INSTALLED METER
FROM tbmasmeter a
JOIN tbmeter b ON a.mtrnum = b.MTRNUM
JOIN tbmtrstatus c ON b.MTRSTAT = c.MTRSTAT
JOIN TBMASSTATUS d ON a.MASMTRSTAT = d.MASMTRSTAT
WHERE d.DESCR = 'FAULTY METER'
  AND c.DESCR = 'ACTIVE';







select * from t_AllMasterType where name like 'met%'




SELECT A.NAME,A.CODE,mastertype
FROM t_AllMaster A,t_AllMasterType B WHERE A.MasterType=B.PKID
AND B.NAME='Meter Type'


select distinct MTRTYP from TBMASMETER

select distinct MTRBRAND from TBMASMETER


select distinct MTRMODEL from TBMASMETER


SELECT DISTINCT DIALLEN FROM TBMASMETER



---------------TARIFF MANAGEMENT--------------------------


SELECT COUNT(*) FROM tbtarctrl


SELECT COUNT(*) FROM TBWTARIFF



SELECT DISTINCT TARTYP FROM tbtarctrl   


SELECT DISTINCT SUPPTYP FROM tbtarctrl 


SELECT COUNT(*) FROM t_TariffControl

SELECT COUNT(*) FROM t_TariffRevision


SELECT COUNT(*) FROM  t_tariffrevisionslab



SELECT A.NAME,A.CODE,mastertype
FROM t_AllMaster A,t_AllMasterType B WHERE A.MasterType=B.PKID
AND B.NAME='TARIFF Type'


-----------------------------ROUTE MANAGEMENT------------------



SELECT COUNT(*) FROM TBROUTE


SELECT COUNT(*) FROM t_Route

SELECT COUNT(*) FROM t_RouteDiscount

SELECT COUNT(*) FROM t_RouteCharge


select disTINCT ACCTYP FROM TBROUTE


select disTINCT ROUTYP FROM TBROUTE	



---------------------Consumer Management-----------------------------



SELECT COUNT(*) FROM TBCONSUMER

SELECT COUNT(*) FROM TBNAPCONS


SELECT COUNT(*) FROM TBNEWAPPGRP

SELECT COUNT(*) FROM TBPOSADDR




SELECT COUNT(*) FROM TBJDEUBISLIST




SELECT COUNT(*) FROM TBJDEUBISLIST



SELECT COUNT(*) FROM TBCONTRACT

SELECT COUNT(*) FROM t_PARTY

SELECT COUNT(*) FROM t_APPLICATION


SELECT COUNT(*) FROM t_applicationgroup



SELECT COUNT(*) FROM t_ConsumerTaxDetail



SELECT COUNT(*) FROM t_ConsumerPOSAddress






SELECT COUNT(*) FROM t_ConsumerJDEAccountDetail



SELECT COUNT(*) FROM t_ConsumerGasLicenseContract


SELECT COUNT(*) FROM TBOPITEMS


SELECT COUNT(*) FROM TBMETER


SELECT COUNT(*) FROM t_OPENITEMS


SELECT COUNT(*) FROM t_INSTALLEDMETER



-------------BILLING MANAGEMENT-------------------------

SELECT COUNT(*) FROM TBBILITMHIST

SELECT COUNT(*) FROM TBBILL


SELECT COUNT(*) FROM TBBILMTRHIST


SELECT COUNT(*) FROM t_BILL

SELECT COUNT(*) FROM t_BILLDETAIL

SELECT COUNT(*) FROM t_BILLMETERREADING



select --top 10 a.bilnum,b.bilnum,bildat
count(*)

from tbbill a ,TBBILITMHIST b where a.bilnum=b.bilnum order by bildat DESC


-------------------------------

SELECT TOP 10 *
FROM GMRSSEP2025.DBO.TBSUPPCMT a
WHERE NOT EXISTS (
    SELECT 1
    FROM GMRSSEP2025.DBO.TBconsumer b
    WHERE a.CONNUM = b.CONNUM
);


--------------------------------------

SELECT 
    a.USRID,
    b.USRID AS UserID_in_UserTable,
    b.USRNAM
FROM TBBILL a
LEFT JOIN TBUSER b ON a.USRID = b.USRID
WHERE b.USRID IS NULL;




------Cylinder Management---

SELECT COUNT(*) FROM TBCYLINDErtyp


SELECT COUNT(*) FROM t_CylTariffControl




SELECT COUNT(*) FROM TBCYLINDERBATCH



SELECT COUNT(*) FROM t_CylinderBillRequest



SELECT COUNT(*) FROM  TBCYLINDERDO


SELECT COUNT(*) FROM t_CylinderDeliveryOrder



SELECT COUNT(*) FROM TBGSUPPLIER



SELECT COUNT(*) FROM t_GasSupplier



SELECT COUNT(*) FROM TBGSUPCONV


SELECT COUNT(*) FROM t_GasSupplierConv


SELECT COUNT(*) FROM TBCYLINDErtyp


SELECT COUNT(*) FROM t_CylTariffRevision


SELECT COUNT(*) FROM t_CylTariffRevisionApproval



--------------------Deposit Managment-------------------------------------



SELECT COUNT(*) FROM TBDEPOSIT


SELECT COUNT(*) FROM T_deposit




SELECT COUNT(*) FROM TBDEPBATCH


SELECT COUNT(*) FROM t_DepositBatch




SELECT COUNT(*) FROM TBDEPBATCH



SELECT COUNT(*) FROM t_ConsumerDepositStatement



SELECT COUNT(*) FROM  TBBANKGUARANTEE


SELECT COUNT(*) FROM  t_BankGuarantee


---------------------------open items---------------------------




SELECT COUNT(*) FROM TBOPITEMS



SELECT COUNT(*) FROM t_openitems


SELECT count(*) FROM TBBILL A WHERE EVNTYP!='3' AND EVNGRP='80'AND EXISTS (SELECT * FROM TBOPITEMS B WHERE A.BILNUM=B.BILNUM)

-------------------payment management------------------



SELECT COUNT(*) FROM TBPAYMENT


SELECT COUNT(*) FROM t_billpayment


SELECT COUNT(*) FROM TBPAYMTBATCH


SELECT COUNT(*) FROM t_PaymentBatch




SELECT COUNT(*) FROM TBSTUBHDR


SELECT COUNT(*) FROM t_PaymentStubHeader


SELECT COUNT(*) FROM TBSTUBTRANS


SELECT COUNT(*) FROM t_PaymentStubDetail





 select 

 count(*)

 from tbpayment a where  exists (select BATCHNUM from TBPAYMTBATCH b where a.BATCHNUM=b.BATCHNUM) 



  select 

 count(*)

 from tbpaymtbatch a where not  exists (select BATCHNUM from TBSTUBHDR b where a.BATCHNUM=b.BATCHNUM) 




select 

 count(*)

 from TBSTUBHDR a where   exists (select BATCHNUM from TBSTUBTRANS b where a.BATCHNUM=b.BATCHNUM) 

--------------------WORK ORDER----------------------------

SELECT COUNT(*) FROM TBWORDER


SELECT COUNT(*) FROM t_WORKORDER




SELECT COUNT(*) FROM TBWONEWAPP



SELECT COUNT(*) FROM t_WONewMeterInstallation



SELECT COUNT(*) FROM  TBWODISCMTR


SELECT COUNT(*) FROM t_WODisconnectMeter



SELECT COUNT(*) FROM TBWOMTRCHG



SELECT COUNT(*) FROM t_WOMeterChange



SELECT COUNT(*) FROM TBWOMTRRDG


SELECT COUNT(*) FROM t_WOMeterReading


SELECT COUNT(*) FROM TBWOADJUST


SELECT COUNT(*) FROM t_WOReadingAdjustment



SELECT COUNT(*) FROM t_WOMeterInspection


SELECT COUNT(*) FROM t_WOMeterInspection






SELECT COUNT(*) FROM TBWOINSPECTION


SELECT COUNT(*) FROM t_WOMeterInspection




SELECT COUNT(*) FROM TBWOSITEINSP


SELECT COUNT(*) FROM t_WOSiteInspection


-----------------REMAINDER MANAGEMENT------------------------------


SELECT COUNT(*) FROM TBREMINDER


SELECT COUNT(*) FROM t_REMINDER



SELECT COUNT(*) FROM TBRLBATCH


SELECT COUNT(*) FROM t_REMINDERBATCH


-------------NON BILL ------------------------------------



SELECT COUNT(*) FROM TBNONBILL


SELECT COUNT(*) FROM t_NONBILL



SELECT COUNT(*) FROM TBNONBILLPAYMENT


SELECT COUNT(*) FROM t_NONBILLPAYMENT





-------------------DISCONNECTION MANANMAENGT-------------------------------------------



SELECT COUNT(*) FROM TBDISCBATCH


SELECT COUNT(*) FROM t_DISCONNECTIONBATCH



SELECT COUNT(*) FROM TBDISCWO


SELECT COUNT(*) FROM t_DisconnectionBatchDetails




SELECT COUNT(*) FROM TBSUPPCMT



SELECT COUNT(*) FROM T_SUPLLYCOMMENT

------------------------------------------------------


select top 10 * from  tbworder where  issuerflag=1


select distinct woperby from  tbworder  where  issuerflag=1 and not exists(select usrid from tbuser where 




	select top 10 * from tbworder



-------------------Cylindar billing management--------------------------

select count(*) from TBCYLINDERBATCH

select count(*) from t_CylinderBillRequest




select count(*) from TBCYLINDErtyp

select count(*) from t_CylTariffControl




select count(*) from  TBCYLINDERDO

select count(*) from t_CylinderDeliveryOrder





 select 

 count(*)

 from  TBCYLINDERDO a where  exists (select cylindercode from TBCYLINDErtyp b where a.cylindercode=b.cylindercode) 


 
 select 

 count(*)

 from  TBCYLINDERDO a where  not exists (select cylindercode from TBGSUPPLIER b where a.supcod=b.supcod) 




 
 select 

 count(*)

 from  TBCYLINDERDO a where   exists (select cylindercode from TBGSUPCONV b where a.supconv=b.supconv) 




 
select count(*) from TBGSUPPLIER

select count(*) from t_GasSupplier




select count(*) from  TBGSUPCONV

select count(*) from t_GasSupplierConv







select count(*) from TBCYLINDErtyp

select count(*) from t_CylTariffRevision




select count(*) from  TBCYLINDERDO

select count(*) from t_CylinderDeliveryOrder




select count(*) from TBCYLINDErtyp

select count(*) from t_CylTariffControl








 select 

 count(*)

 from  TBCYLINDErtyp a where   exists (select cylindercode from TBCYLINDErtyp b where a. cylindercode=b. cylindercode) 




 select count(*) from  TBCYLINDERDO

select count(*) from t_CylinderDeliveryOrder




select count(*) from TBCYLINDErtyp

select count(*) from t_CylTariffControl




select count(*) from t_CylTariffRevision



select count(*) from t_CylTariffRevisionapproval

